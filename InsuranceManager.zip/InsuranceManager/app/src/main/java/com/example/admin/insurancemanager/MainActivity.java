package com.example.admin.insurancemanager;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity
{
    private EditText editName;
    private EditText editPassword;
    private Button btnSignin;

    private String state = "";
    public static String NAME;

    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 2)
            {
                if(state.equals("100"))
                {
                    progressDialog.cancel();
                    NAME = editName.getText().toString();
                    Intent intent = new Intent(MainActivity.this, PolicyActivity.class);
                    startActivity(intent);
                }
                else if(state.equals("200"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Phone number might be wrong. Please check again.",Toast.LENGTH_SHORT).show();
                }
                else if(state.equals("201"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Password might be wrong. Please check again.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                /*if(editPassword.getText().toString().equals("1")) {
                    PHONE = editPhone.getText().toString();

                    Intent intent = new Intent(MainActivity.this, PolicyActivity.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(),"Password might be wrong. Please check again.",Toast.LENGTH_SHORT).show();
                }*/
                if(!state.equals("100"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editName = (EditText) this.findViewById(R.id.sign_in_et_username);
        editPassword = (EditText) this.findViewById(R.id.sign_in_et_password);
        btnSignin = (Button) this.findViewById(R.id.btn_sign_in);
    }

    public void Sign_in(View v)
    {
        String name = editName.getText().toString();
        String password = editPassword.getText().toString();

        if(name.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Username can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if(password.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Password can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else
        {
            final JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("phone_number", name);
                jsonObject.put("password", password);
                System.out.println(jsonObject.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Thread tread = new Thread(new Runnable() {
                @Override
                public void run()
                {
                    String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/staff/login");
                    System.out.println("The string get from server is: " + str);
                    try
                    {
                        JSONObject getJsonObject = new JSONObject(str);
                        state = getJsonObject.getString("Checkcode");
                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                    Message msg = new Message();
                    msg.what = 2;
                    handler.sendMessage(msg);
                }
            });
            tread.start();

            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Please wait......");
            progressDialog.setMessage("Signing in......");
            progressDialog.setIndeterminate(true);
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            Thread thread = new Thread()
            {
                public void run()
                {
                    try
                    {
                        sleep(10*1000);
                    }
                    catch(InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                    progressDialog.cancel();
                    Message msg = new Message();
                    msg.what = 101;
                    handler.sendMessage(msg);
                }
            };
            thread.start();
        }
    }
}
