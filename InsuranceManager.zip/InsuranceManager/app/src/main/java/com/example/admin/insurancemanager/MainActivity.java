package com.example.admin.insurancemanager;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity
{

    private EditText editPhone;
    private EditText editPassword;
    private Button btnSignin;

    private String state;
    public static String PHONE;

    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 2)
            {
                if(state.equals("account.html"))
                {
                    progressDialog.cancel();
                    PHONE = editPhone.getText().toString();
                    Intent intent = new Intent(MainActivity.this, PolicyActivity.class);
                    startActivity(intent);
                }
                else if(state.equals("not exist"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Phone number might be wrong. Please check again.",Toast.LENGTH_SHORT).show();
                }
                else if(state.equals("Wrong password"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Password might be wrong. Please check again.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                /*if(editPassword.getText().toString().equals("1")) {
                    PHONE = editPhone.getText().toString();

                    Intent intent = new Intent(MainActivity.this, PolicyActivity.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(),"Password might be wrong. Please check again.",Toast.LENGTH_SHORT).show();
                }*/
                if(!state.equals("account.html"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editPhone = (EditText) this.findViewById(R.id.sign_in_et_username);
        editPassword = (EditText) this.findViewById(R.id.sign_in_et_password);
        btnSignin = (Button) this.findViewById(R.id.btn_sign_in);
    }

    public void Sign_in(View v)
    {
        String phone = editPhone.getText().toString();
        String password = editPassword.getText().toString();

        if(phone.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Phone number can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if(password.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Password can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else
        {
            final JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("phone", phone);
                jsonObject.put("password", password);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Thread tread = new Thread(new Runnable() {
                @Override
                public void run() {
                    String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/staff/login");
                    System.out.println("The string get from server is: " + str);
                    state = str;
                    Message msg = new Message();
                    msg.what = 2;
                    handler.sendMessage(msg);
                }
            });
            tread.start();

            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Please want......");
            progressDialog.setMessage("Signing in......");
            progressDialog.setIndeterminate(true);
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            Thread thread = new Thread()
            {
                public void run()
                {
                    try
                    {
                        sleep(10*1000);
                    }
                    catch(InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                    progressDialog.cancel();
                    Message msg = new Message();
                    msg.what = 101;
                    handler.sendMessage(msg);
                }
            };
            thread.start();
        }
    }
}
