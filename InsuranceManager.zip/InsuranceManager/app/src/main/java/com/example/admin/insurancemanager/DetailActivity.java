package com.example.admin.insurancemanager;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;

public class DetailActivity extends AppCompatActivity
{
    private EditText editPolicyID;
    private EditText editPolicyName;
    private EditText editStartDate;
    private EditText editEndDate;
    private EditText editPhone;
    private EditText editTime;
    private EditText editPlace;
    private EditText editDescription;
    private EditText editValue;
    private TextView textPhoto;
    private ImageView imgState1;
    private RadioGroup rgState1;
    private RadioButton rgState1_2;
    private RadioButton rgState1_3;
    private RadioGroup rgState2;
    private RadioButton rgState2_0;
    private RadioButton rgState2_1;
    private RadioButton rgState2_2;
    private RadioGroup rgState3;
    private RadioButton rgState3_0;
    private RadioButton rgState3_1;
    private RadioButton rgState3_2;
    private EditText editFeedback1;
    private EditText editFeedback2;
    private EditText editFeedback3;
    private ImageView btnBack;
    private Button btnSubmit;

    private String policyID;
    private String policyName;
    private String startDate;
    private String endDate;
    private String phone;
    private String time;
    private String place;
    private String description;
    private String value;
    private String photoString;
    private Bitmap photobm = null;
    private Dialog dialog = null;
    private ImageView mImageView = null;
    private String feedback1 = "xxxx";
    private String feedback2 = "xxxx";
    private String feedback3 = "xxxx";
    private String claimState1 = "0";
    private String claimState2 = "0";
    private String claimState3 = "0";
    private String state = "";
    private String message = "";
    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 6)
            {
                if(state.equals("100"))
                {
                    progressDialog.cancel();
                    editPolicyID.setText(policyID);
                    editPolicyName.setText(policyName);
                    editStartDate.setText(startDate);
                    editEndDate.setText(endDate);
                    editPhone.setText(phone);
                    editTime.setText(time);
                    editPlace.setText(place);
                    editDescription.setText(description);
                    editValue.setText(value);
                    ////////////////imgPhoto.setImageDrawable(photo);

                    if(!feedback1.equals("xxxx"))
                    {
                        editFeedback1.setText(feedback1);
                    }
                    if(!feedback2.equals("xxxx"))
                    {
                        editFeedback2.setText(feedback2);
                    }
                    if(!feedback3.equals("xxxx"))
                    {
                        editFeedback3.setText(feedback3);
                    }

                    if(claimState1.equals("1"))
                    {
                        imgState1.setImageResource(R.drawable.step123_1);
                        editFeedback2.setEnabled(false);
                        editFeedback3.setEnabled(false);
                        editFeedback2.setFocusable(false);
                        editFeedback3.setFocusable(false);
                        rgState2_1.setEnabled(false);
                        rgState2_2.setEnabled(false);
                        rgState3_1.setEnabled(false);
                        rgState3_2.setEnabled(false);
                    }
                    else if(claimState1.equals("2"))
                    {
                        imgState1.setImageResource(R.drawable.step123_2);
                        editFeedback1.setEnabled(false);
                        editFeedback1.setFocusable(false);
                        rgState1_2.setEnabled(false);
                        rgState1_3.setEnabled(false);

                        if(claimState2.equals("0"))
                        {
                            editFeedback3.setEnabled(false);
                            editFeedback3.setFocusable(false);
                            rgState3_1.setEnabled(false);
                            rgState3_2.setEnabled(false);
                        }
                        else
                        {
                            editFeedback2.setEnabled(false);
                            editFeedback2.setFocusable(false);
                            rgState2_1.setEnabled(false);
                            rgState2_2.setEnabled(false);
                        }
                    }
                    else if(claimState1.equals("3"))
                    {
                        imgState1.setImageResource(R.drawable.step123_3);
                        editFeedback1.setEnabled(false);
                        editFeedback2.setEnabled(false);
                        editFeedback3.setEnabled(false);
                        editFeedback1.setFocusable(false);
                        editFeedback2.setFocusable(false);
                        editFeedback3.setFocusable(false);
                        rgState1_2.setEnabled(false);
                        rgState1_3.setEnabled(false);
                        rgState2_1.setEnabled(false);
                        rgState2_2.setEnabled(false);
                        rgState3_1.setEnabled(false);
                        rgState3_2.setEnabled(false);
                    }

                    if((claimState1.equals("3") && claimState2.equals("0") && claimState3.equals("0")) || (claimState1.equals("1") && claimState2.equals("0") && claimState3.equals("0")))
                    {
                        rgState1.check(rgState1_3.getId());
                    }
                    else
                    {
                        rgState1.check(rgState1_2.getId());
                    }

                    if(claimState2.equals("0"))
                    {
                        rgState2.check(rgState2_0.getId());
                    }
                    else if(claimState2.equals("1"))
                    {
                        rgState2.check(rgState2_1.getId());
                    }
                    else if(claimState2.equals("2"))
                    {
                        rgState2.check(rgState2_2.getId());
                    }

                    if(claimState3.equals("0"))
                    {
                        rgState3.check(rgState3_0.getId());
                    }
                    else if(claimState3.equals("1"))
                    {
                        rgState3.check(rgState3_1.getId());
                    }
                    else if(claimState3.equals("2"))
                    {
                        rgState3.check(rgState3_2.getId());
                    }
                }
                else if(state.equals("200"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"This chaim does not exist.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 7)
            {
                if(state.equals("100"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Succeed.",Toast.LENGTH_SHORT).show();
                    finish();
                }
                else
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Something wrong with this chaim.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(!state.equals("100"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.policy_details);

        editPolicyID = (EditText) findViewById(R.id.policyNumber_input);
        editPolicyName = (EditText)findViewById(R.id.policyName_Input);
        editStartDate = (EditText) findViewById(R.id.Start_Date);
        editEndDate = (EditText)findViewById(R.id.End_Date);
        editPhone = (EditText)findViewById(R.id.policyPhone_Input);
        editTime = (EditText)findViewById(R.id.policyTime_Input);
        editPlace = (EditText)findViewById(R.id.policyLocation_Input);
        editDescription = (EditText)findViewById(R.id.policyReason_Input);
        editValue = (EditText)findViewById(R.id.policyPrice_Input);
        textPhoto = (TextView)findViewById(R.id.detail_textView1);
        imgState1 = (ImageView) findViewById(R.id.Detail_imageView2);
        rgState1 = (RadioGroup) findViewById(R.id.application_accept_group);
        rgState1_2 = (RadioButton) findViewById(R.id.application_accept_yes);
        rgState1_3 = (RadioButton) findViewById(R.id.application_accept_no);
        rgState2 = (RadioGroup) findViewById(R.id.find_package);
        rgState2_0 = (RadioButton) findViewById(R.id.find_package_unsure);
        rgState2_1 = (RadioButton) findViewById(R.id.find_package_no);
        rgState2_2 = (RadioButton) findViewById(R.id.find_package_yes);
        rgState3 = (RadioGroup) findViewById(R.id.if_paid);
        rgState3_0 = (RadioButton) findViewById(R.id.if_paid_unsure);
        rgState3_1 = (RadioButton) findViewById(R.id.if_paid_no);
        rgState3_2 = (RadioButton) findViewById(R.id.if_paid_yes);
        editFeedback1 = (EditText) findViewById(R.id.accept_feedback);
        editFeedback2 = (EditText) findViewById(R.id.find_package_feedback);
        editFeedback3 = (EditText) findViewById(R.id.claim_feedback);
        btnSubmit = (Button) findViewById(R.id.detail_modify);
        btnBack = (ImageView) findViewById(R.id.excel_back);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        policyID = bundle.getString("policyID");



      /*  policyID = "123123";
        try
        {
            String str = "{\"Checkcode\":\"100\",\"Message\":{\"policy_number\":\"123\",\"policy_name\":\"xxxxxxxxxxxxx\",\"phone_number\":\"13123456789\",\"time\":\"yyyy/mm/dd/hh/mm\",\"place\":\"xxxx\",\"reason\":\"xxxxxxxxxxxxxxxxx\",\"price\":\"xxxx\",\"picture\":\"x0123412edx3\",\"feedback\":\"xxx123xxx@@xxxxxxxxceqwdsax@@asdasd\",\"claim_states\": \"2@@1@@0\"}}";
            JSONObject getMsg = new JSONObject(str);
            state = getMsg.getString("Checkcode");
            message = getMsg.getString("Message");

            JSONObject getJsonObject = new JSONObject(message);
            policyName = getJsonObject.getString("policy_name");
            phone = getJsonObject.getString("phone_number");
            time = getJsonObject.getString("time");
            place = getJsonObject.getString("place");
            description = getJsonObject.getString("reason");
            value = getJsonObject.getString("price");
            ///////////photo = getJsonObject.getString("picture");

            String msgFeedback = getJsonObject.getString("feedback");
            ArrayList<String> feedbackList = new ArrayList<String>(Arrays.asList(msgFeedback.split("@@")));
            feedback1 = feedbackList.get(0);
            feedback2 = feedbackList.get(1);
            feedback3 = feedbackList.get(2);

            String msgState = getJsonObject.getString("claim_states");
            ArrayList<String> stateList = new ArrayList<String>(Arrays.asList(msgState.split("@@")));
            claimState1 = stateList.get(0);
            claimState2 = stateList.get(1);
            claimState3 = stateList.get(2);
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
        Message msg = new Message();
        msg.what = 6;
        handler.sendMessage(msg);*/








        final JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("policy_number", policyID);
            jsonObject.put("states", PolicyActivity.filterState);
            System.out.println(jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Thread tread = new Thread(new Runnable() {
            @Override
            public void run() {
                String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/staff/lost_luggage/one_Message");
                System.out.println("The string get from server is: " + str);
                try
                {
                    JSONObject getMsg = new JSONObject(str);
                    state = getMsg.getString("Checkcode");
                    message = getMsg.getString("Message");

                    try
                    {
                        JSONObject getJsonObject = new JSONObject(message);
                        policyName = getJsonObject.getString("policy_name");
                        startDate = getJsonObject.getString("start_time");
                        endDate = getJsonObject.getString("end_time");
                        phone = getJsonObject.getString("phone_number");
                        time = getJsonObject.getString("time");
                        place = getJsonObject.getString("place");
                        description = getJsonObject.getString("reason");
                        value = getJsonObject.getString("price");
                        photoString = getJsonObject.getString("picture");

                        String msgFeedback = getJsonObject.getString("feedback");
                        ArrayList<String> feedbackList = new ArrayList<String>(Arrays.asList(msgFeedback.split("@@")));
                        feedback1 = feedbackList.get(0);
                        feedback2 = feedbackList.get(1);
                        feedback3 = feedbackList.get(2);

                        String msgState = getJsonObject.getString("states");
                        ArrayList<String> stateList = new ArrayList<String>(Arrays.asList(msgState.split("@@")));
                        claimState1 = stateList.get(0);
                        claimState2 = stateList.get(1);
                        claimState3 = stateList.get(2);
                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }

                Message msg = new Message();
                msg.what = 6;
                handler.sendMessage(msg);
            }
        });
        tread.start();

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please want......");
        progressDialog.setMessage("Loading......");
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        Thread thread = new Thread()
        {
            public void run()
            {
                try
                {
                    sleep(30*1000);
                }
                catch(InterruptedException e)
                {
                    e.printStackTrace();
                }
                progressDialog.cancel();
                Message msg = new Message();
                msg.what = 101;
                handler.sendMessage(msg);
            }
        };
        thread.start();
    }

    public void Submit_Change(View v)
    {
        if (claimState1.equals("1"))
        {
            final JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("policy_number", policyID);
                jsonObject.put("feedback", editFeedback1.getText());
                if(rgState1_2.isChecked())
                {
                    jsonObject.put("isAccept", 1);
                }
                else if(rgState1_3.isChecked())
                {
                    jsonObject.put("isAccept", 0);
                }
                jsonObject.put("staff_number", MainActivity.NAME);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            Thread tread = new Thread(new Runnable() {
                @Override
                public void run() {
                    String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/staff/lost_luggage/claim_accept_OR_reject");
                    System.out.println("The string get from server is: " + str);
                    try
                    {
                        JSONObject getJsonObject = new JSONObject(str);
                        state = getJsonObject.getString("Checkcode");

                        Message msg = new Message();
                        msg.what = 7;
                        handler.sendMessage(msg);
                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                }
            });
            tread.start();
        }
        else if (claimState1.equals("2"))
        {
            if(claimState2.equals("0"))
            {
                final JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("policy_number", policyID);
                    jsonObject.put("feedback", editFeedback2.getText());
                    if(rgState2_1.isChecked())
                    {
                        jsonObject.put("states", "1");
                    }
                    else if(rgState2_2.isChecked())
                    {
                        jsonObject.put("states", "2");
                    }
                    jsonObject.put("isTheLastSubmit", "0");
                    System.out.println(jsonObject.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                Thread tread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/staff/lost_luggage/feedback_submit");
                        System.out.println("The string get from server is: " + str);
                        try
                        {
                            JSONObject getJsonObject = new JSONObject(str);
                            state = getJsonObject.getString("Checkcode");

                            Message msg = new Message();
                            msg.what = 7;
                            handler.sendMessage(msg);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                });
                tread.start();
            }
            else
            {
                final JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("policy_number", policyID);
                    jsonObject.put("feedback", editFeedback3.getText());
                    if(rgState3_1.isChecked())
                    {
                        jsonObject.put("states", "1");
                    }
                    else if(rgState3_2.isChecked())
                    {
                        jsonObject.put("states", "2");
                    }
                    jsonObject.put("isTheLastSubmit", "1");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                Thread tread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/staff/lost_luggage/feedback_submit");
                        System.out.println("The string get from server is: " + str);
                        try
                        {
                            JSONObject getJsonObject = new JSONObject(str);
                            state = getJsonObject.getString("Checkcode");

                            Message msg = new Message();
                            msg.what = 7;
                            handler.sendMessage(msg);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                });
                tread.start();
            }

        }

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please wait......");
        progressDialog.setMessage("Loading......");
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        Thread thread = new Thread()
        {
            public void run()
            {
                try
                {
                    sleep(10*1000);
                }
                catch(InterruptedException e)
                {
                    e.printStackTrace();
                }
                progressDialog.cancel();
                Message msg = new Message();
                msg.what = 101;
                handler.sendMessage(msg);
            }
        };
        thread.start();
    }

    public void Show_photo(View v)
    {
        byte[] b = new byte[0];
        try
        {
            b = photoString.getBytes("ISO-8859-1");
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        System.out.println("The byte get from server is: " + b);
        photobm = BitmapFactory.decodeByteArray(b, 0, b.length);

        dialog = new Dialog(DetailActivity.this, R.style.edit_AlertDialog_style);
        mImageView = getImageView();
        mImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.setContentView(mImageView);
        dialog.setCanceledOnTouchOutside(true);
        dialog.show();
    }

    private ImageView getImageView()
    {
        ImageView iv = new ImageView(this);
        //宽高
        iv.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        //设置Padding
        iv.setPadding(20,20,20,20);
        //imageView设置图片
        iv.setImageBitmap(photobm);
        return iv;
    }

    public void Back(View v)
    {
        finish();
    }
}
