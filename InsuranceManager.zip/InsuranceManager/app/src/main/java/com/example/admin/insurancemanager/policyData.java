package com.example.admin.insurancemanager;

public class policyData {
	private String policyId;
	private String value;
	private String place;
	private String time;

	public policyData(String policyId, String value, String place, String time) {
		this.policyId=policyId;
		this.value=value;
		this.place=place;
		this.time=time;
	}
	public String getPolicyId() {
		return policyId;
	}
	public String getValue() { return value; }
	public String getPlace() {
		return place;
	}
	public String getTime() {
		return time;
	}
}
