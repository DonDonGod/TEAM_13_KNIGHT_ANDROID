package com.example.admin.insurancemanager;

import java.util.ArrayList;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

public class Message3Fragment extends Fragment{

	  public View onCreateView(LayoutInflater inflater, ViewGroup container,
	       Bundle savedInstanceState) {
	    View messageLayout = inflater.inflate(R.layout.fragment3, container, false);
   
	    ListView listview=(ListView) messageLayout.findViewById(R.id.listView3);
		  listview.setOnItemClickListener(new AdapterView.OnItemClickListener()
		  {
			  @Override
			  public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
			  {
				  Intent intent = new Intent(getActivity(), DetailActivity.class);
				  intent.putExtra("policyID", PolicyActivity.policylist.get(i).getPolicyId());
				  startActivity(intent);
			  }
		  });
		  policyAdapter adapter=new policyAdapter(getActivity(),R.layout.layout_listview,PolicyActivity.policylist);

		
		listview.setAdapter(adapter);
	    
	    return messageLayout; 
	   }
	  
	  

	}