package com.example.admin.insurancemanager;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class PolicyActivity extends AppCompatActivity
{
    private TextView textPolicyId;
    private TextView textTime;

    private String policyId;
    private String claimTime;

    private ProgressDialog progressDialog = null;
    private ArrayList<String> arrayList = null;
    private Policy[] allPolicy;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 6)
            {
                if(!policyId.equals(""))
                {
                    progressDialog.cancel();
                    for(int i = 0; i < allPolicy.length; i++)
                    {
                        textPolicyId.setText(allPolicy[i].getId());
                        textTime.setText(allPolicy[i].getTime());
                    }
                }
                else
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"This form has already existed.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(policyId.equals(""))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_policy);

        textPolicyId = (TextView) this.findViewById(R.id.textView1_2);
        textTime = (TextView) this.findViewById(R.id.textView1_4);

        Thread tread = new Thread(new Runnable() {
            @Override
            public void run() {
                String str = SendServer.sendServer("", "http://101.132.96.76:8080/staff/lost_luggage");
                System.out.println("The string get from server is: " + str);
                str = str.replace("[","");
                str = str.replace("]","");
                System.out.println("Now is: " + str);
                arrayList = new ArrayList<String>(Arrays.asList(str.split(",")));
                System.out.println(arrayList.toString());
                try
                {
                    for(int i = 0; i < arrayList.size(); i++)
                    {
                        JSONObject getJsonObject = new JSONObject(arrayList.get(i));
                        System.out.println(getJsonObject.toString());
                        allPolicy[i] = new Policy(getJsonObject.getString("policy_number"), getJsonObject.getString("time"), getJsonObject.getString("date"), getJsonObject.getString("reason"), getJsonObject.getString("remark"), getJsonObject.getString("price"));
                    }

                    Message msg = new Message();
                    msg.what = 6;
                    handler.sendMessage(msg);
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
            }
        });
        tread.start();

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please want......");
        progressDialog.setMessage("Loading......");
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        Thread thread = new Thread()
        {
            public void run()
            {
                try
                {
                    sleep(10*1000);
                }
                catch(InterruptedException e)
                {
                    e.printStackTrace();
                }
                progressDialog.cancel();
                Message msg = new Message();
                msg.what = 101;
                handler.sendMessage(msg);
            }
        };
        thread.start();
    }

    public void Show_detail(View v)
    {

    }
}
