package com.example.admin.insurancemanager;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class PolicyActivity extends AppCompatActivity implements View.OnClickListener
{
    private Spinner spinner1;
    private Spinner spinner2;
    private Spinner spinner3;

    public static String filterState = "102";//101 not processed  102 processing  103 processed
    private String filterTime = "101";//101 ascending最新  102 descending最老
    private String filterValue = "101";//101 0-100  102 100-1000  103 1000-10000  104 10000+
    private String filterPlace = "all";//Beijing  Hangzhou  London
    private String state = "";
    private String message = "";
    private ProgressDialog progressDialog = null;
    private JSONArray arrayList = null;
    public static ArrayList<policyData> policylist;

    private Message1Fragment messageFragment;
    private Message2Fragment contactsFragment;
    private Message3Fragment newsFragment;
    private View messageLayout;
    private View contactsLayout;
    private View newsLayout;
    private View settingLayout;
    private FragmentManager fragmentManager;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 6)
            {
                if(state.equals("100"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Succeed.",Toast.LENGTH_SHORT).show();
                }
                else if(state.equals("200"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Something wrong with server. Please try again.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(!state.equals("100"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_policy);

        spinner1 = (Spinner) findViewById(R.id.spinner1);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id)
            {
                String[] location = getResources().getStringArray(R.array.location);
                if (location[pos].equals("Beijing"))
                {
                    filterPlace = "Beijing";
                }
                else if (location[pos].equals("Hangzhou"))
                {
                    filterPlace = "Hangzhou";
                }
                else if (location[pos].equals("London"))
                {
                    filterPlace = "London";
                }

                System.out.println("state: " + filterState);
                System.out.println("place: " + filterPlace);
                System.out.println("time: " + filterTime);
                System.out.println("value: " + filterValue);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // Another interface callback
            }
        });
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id)
            {
                String[] time1 = getResources().getStringArray(R.array.time1);
                if (time1[pos].equals("Ascending"))
                {
                    filterTime = "101";
                }
                else if (time1[pos].equals("Descending"))
                {
                    filterTime = "102";
                }

                System.out.println("state: " + filterState);
                System.out.println("place: " + filterPlace);
                System.out.println("time: " + filterTime);
                System.out.println("value: " + filterValue);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // Another interface callback
            }
        });
        spinner3 = (Spinner) findViewById(R.id.spinner3);
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id)
            {
                String[] pricy = getResources().getStringArray(R.array.pricy);
                if (pricy[pos].equals("0-100 dollar"))
                {
                    filterValue = "101";
                }
                else if (pricy[pos].equals("100-1000 dollar"))
                {
                    filterValue = "102";
                }
                else if (pricy[pos].equals("1000-10000 dollar"))
                {
                    filterValue = "103";
                }
                else if (pricy[pos].equals("10000+ dollar"))
                {
                    filterValue = "104";
                }

                System.out.println("state: " + filterState);
                System.out.println("place: " + filterPlace);
                System.out.println("time: " + filterTime);
                System.out.println("value: " + filterValue);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // Another interface callback
            }
        });

        Spinner spinner1 = (Spinner) findViewById(R.id.spinner1);
        ArrayAdapter adapter1 = ArrayAdapter.createFromResource(this, R.array.location,R.layout.layout_spinner1_1);
        adapter1.setDropDownViewResource(R.layout.layout_spinner2);
        spinner1.setAdapter(adapter1);

        Spinner spinner2 = (Spinner) findViewById(R.id.spinner2);
        ArrayAdapter adapter2 = ArrayAdapter.createFromResource(this, R.array.time1,R.layout.layout_spinner1_2);
        adapter2.setDropDownViewResource(R.layout.layout_spinner2);
        spinner2.setAdapter(adapter2);

        Spinner spinner3 = (Spinner) findViewById(R.id.spinner3);
        ArrayAdapter adapter3 = ArrayAdapter.createFromResource(this, R.array.pricy,R.layout.layout_spinner1_3);
        adapter3.setDropDownViewResource(R.layout.layout_spinner2);
        spinner3.setAdapter(adapter3);


        initViews();
        fragmentManager = getFragmentManager();
        // 第一次启动时选中第2个tab
        setTabSelection(1);

        policylist = new ArrayList<policyData>();


        //test
        /*try
        {
            JSONObject getMsg = new JSONObject("{\"Checkcode\":100,\"Message\":[{\"policy_number\":\"123\",\"time\":\"yyyy/mm/dd/hh/mm\",\"place\":\"Beijing\",\"price\":\"101\"},{\"policy_number\":\"666\",\"time\":\"yyyy/mm/dd/hh/mm\",\"place\":\"Beijing\",\"price\":\"102\"},{\"policy_number\":\"111\",\"time\":\"yyyy/mm/dd/hh/mm\",\"place\":\"Beijing\",\"price\":\"103\"},{\"policy_number\":\"12223\",\"time\":\"yyyy/mm/dd/hh/mm\",\"place\":\"Beijing\",\"price\":\"104\"}]}");
            state = getMsg.getString("Checkcode");
            message = getMsg.getString("Message");

            arrayList= new JSONArray(message);
            System.out.println(arrayList.toString());
            try
            {
                for(int i = 0; i < arrayList.length(); i++)
                {
                    JSONObject jsob = new JSONObject(arrayList.get(i).toString());
                    policylist.add(new policyData(jsob.getString("policy_number"), jsob.getString("price"), jsob.getString("place"), jsob.getString("time")));
                }
            }
            catch (JSONException e)
            {
                e.printStackTrace();
            }
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        Message msg = new Message();
        msg.what = 6;
        handler.sendMessage(msg);*/
    }

    private void initViews()
    {
        messageLayout = findViewById(R.id.message_layout);
        contactsLayout = findViewById(R.id.contacts_layout);
        newsLayout = findViewById(R.id.news_layout);

        messageLayout.setOnClickListener(this);
        contactsLayout.setOnClickListener(this);
        newsLayout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.message_layout:
                // 当点击了消息tab时，选中第1个tab
                setTabSelection(0);
                break;
            case R.id.contacts_layout:
                // 当点击了联系人tab时，选中第2个tab
                setTabSelection(1);
                break;
            case R.id.news_layout:
                // 当点击了动态tab时，选中第3个tab
                setTabSelection(2);
                break;

            default:
                break;
        }

    }

    /**
     * 根据传入的index参数来设置选中的tab页。
     *
     * @param index
     * 每个tab页对应的下标。0表示消息，1表示联系人，2表示动态，3表示设置。
     */
    private void setTabSelection(int index) {
        // 每次选中之前先清楚掉上次的选中状态
        clearSelection();
        // 开启一个Fragment事务
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        // 先隐藏掉所有的Fragment，以防止有多个Fragment显示在界面上的情况
        hideFragments(transaction);
        switch (index) {
            case 0:
                messageLayout.setBackgroundColor(Color.parseColor("#FFE1FF"));
                filterState = "101";
                    // 如果MessageFragment为空，则创建一个并添加到界面上

                    final JSONObject jsonObject1 = new JSONObject();
                    try {
                        jsonObject1.put("length", "10");
                        jsonObject1.put("states", "101");
                        jsonObject1.put("time", filterTime);
                        jsonObject1.put("place", filterPlace);
                        jsonObject1.put("price", filterValue);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Thread tread1 = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            String str = SendServer.sendServer(jsonObject1.toString(), "http://101.132.96.76:8080/staff/lost_luggage/list");
                            System.out.println("The string get from server is: " + str);
                            try {
                                JSONObject getMsg = new JSONObject(str);
                                state = getMsg.getString("Checkcode");
                                message = getMsg.getString("Message");

                                arrayList = new JSONArray(message);
                                System.out.println(arrayList.toString());
                                try {
                                    policylist = new ArrayList<policyData>();
                                    for (int i = 0; i < arrayList.length(); i++) {
                                        JSONObject jsob = new JSONObject(arrayList.get(i).toString());
                                        policylist.add(new policyData(jsob.getString("policy_number"), jsob.getString("price"), jsob.getString("place"), jsob.getString("time")));
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            Message msg = new Message();
                            msg.what = 6;
                            handler.sendMessage(msg);
                        }
                    });
                    tread1.start();

                    progressDialog = new ProgressDialog(this);
                    progressDialog.setTitle("Please wait......");
                    progressDialog.setMessage("Loading......");
                    progressDialog.setIndeterminate(true);
                    progressDialog.setCancelable(false);
                    progressDialog.setCanceledOnTouchOutside(false);
                    progressDialog.show();
                    Thread thread11 = new Thread() {
                        public void run() {
                            try {
                                sleep(10 * 1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            progressDialog.cancel();
                            Message msg = new Message();
                            msg.what = 101;
                            handler.sendMessage(msg);
                        }
                    };
                    thread11.start();
                if(messageFragment != null) {
                    transaction.remove(messageFragment);
                }
                    messageFragment = new Message1Fragment();
                    transaction.add(R.id.content, messageFragment);

                break;
            case 1:
                // 当点击了联系人tab时，改变控件的图片和文字颜色
                contactsLayout.setBackgroundColor(Color.parseColor("#FFE1FF"));
                filterState = "102";


                System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");


                    final JSONObject jsonObject2 = new JSONObject();
                    try {
                        jsonObject2.put("length", "10");
                        jsonObject2.put("states", "102");
                        jsonObject2.put("time", filterTime);
                        jsonObject2.put("place", filterPlace);
                        jsonObject2.put("price", filterValue);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Thread tread2 = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            String str = SendServer.sendServer(jsonObject2.toString(), "http://101.132.96.76:8080/staff/lost_luggage/list");
                            System.out.println("The string get from server is: " + str);
                            try {
                                JSONObject getMsg = new JSONObject(str);
                                state = getMsg.getString("Checkcode");
                                message = getMsg.getString("Message");

                                arrayList = new JSONArray(message);
                                System.out.println(arrayList.toString());
                                try {
                                    policylist = new ArrayList<policyData>();
                                    for (int i = 0; i < arrayList.length(); i++) {
                                        JSONObject jsob = new JSONObject(arrayList.get(i).toString());
                                        policylist.add(new policyData(jsob.getString("policy_number"), jsob.getString("price"), jsob.getString("place"), jsob.getString("time")));
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            Message msg = new Message();
                            msg.what = 6;
                            handler.sendMessage(msg);
                        }
                    });
                    tread2.start();

                    progressDialog = new ProgressDialog(this);
                    progressDialog.setTitle("Please wait......");
                    progressDialog.setMessage("Loading......");
                    progressDialog.setIndeterminate(true);
                    progressDialog.setCancelable(false);
                    progressDialog.setCanceledOnTouchOutside(false);
                    progressDialog.show();
                    Thread thread22 = new Thread() {
                        public void run() {
                            try {
                                sleep(10 * 1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            progressDialog.cancel();
                            Message msg = new Message();
                            msg.what = 101;
                            handler.sendMessage(msg);
                        }
                    };
                    thread22.start();
                if(contactsFragment != null) {
                    transaction.remove(contactsFragment);
                }
                    contactsFragment = new Message2Fragment();
                    transaction.add(R.id.content, contactsFragment);
                break;
            case 2:
                // 当点击了动态tab时，改变控件的图片和文字颜色
                newsLayout.setBackgroundColor(Color.parseColor("#FFE1FF"));
                filterState = "103";

                    final JSONObject jsonObject3 = new JSONObject();
                    try {
                        jsonObject3.put("length", "10");
                        jsonObject3.put("states", "103");
                        jsonObject3.put("time", filterTime);
                        jsonObject3.put("place", filterPlace);
                        jsonObject3.put("price", filterValue);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Thread tread3 = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            String str = SendServer.sendServer(jsonObject3.toString(), "http://101.132.96.76:8080/staff/lost_luggage/list");
                            System.out.println("The string get from server is: " + str);
                            try
                            {
                                JSONObject getMsg = new JSONObject(str);
                                state = getMsg.getString("Checkcode");
                                message = getMsg.getString("Message");

                                arrayList= new JSONArray(message);
                                System.out.println(arrayList.toString());
                                try
                                {
                                    policylist = new ArrayList<policyData>();
                                    for(int i = 0; i < arrayList.length(); i++)
                                    {
                                        JSONObject jsob = new JSONObject(arrayList.get(i).toString());
                                        policylist.add(new policyData(jsob.getString("policy_number"), jsob.getString("price"), jsob.getString("place"), jsob.getString("time")));
                                    }
                                }
                                catch (JSONException e)
                                {
                                    e.printStackTrace();
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }

                            Message msg = new Message();
                            msg.what = 6;
                            handler.sendMessage(msg);
                        }
                    });
                    tread3.start();

                    progressDialog = new ProgressDialog(this);
                    progressDialog.setTitle("Please wait......");
                    progressDialog.setMessage("Loading......");
                    progressDialog.setIndeterminate(true);
                    progressDialog.setCancelable(false);
                    progressDialog.setCanceledOnTouchOutside(false);
                    progressDialog.show();
                    Thread thread33 = new Thread()
                    {
                        public void run()
                        {
                            try
                            {
                                sleep(10*1000);
                            }
                            catch(InterruptedException e)
                            {
                                e.printStackTrace();
                            }
                            progressDialog.cancel();
                            Message msg = new Message();
                            msg.what = 101;
                            handler.sendMessage(msg);
                        }
                    };
                    thread33.start();
                if(newsFragment != null) {
                    transaction.remove(newsFragment);
                }
                    newsFragment = new Message3Fragment();
                    transaction.add(R.id.content, newsFragment);
                break;

        }
        transaction.commit();
    }

    /**
     * 将所有的Fragment都置为隐藏状态。
     *
     * @param transaction
     * 用于对Fragment执行操作的事务
     */
    private void hideFragments(FragmentTransaction transaction) {
        if (messageFragment != null) {
            transaction.hide(messageFragment);
        }
        if (contactsFragment != null) {
            transaction.hide(contactsFragment);
        }
        if (newsFragment != null) {
            transaction.hide(newsFragment);
        }

    }

    /**
     * 清除掉所有的选中状态。
     */
    private void clearSelection() {
        messageLayout.setBackgroundColor(0xffffffff);
        contactsLayout.setBackgroundColor(0xffffffff);
        newsLayout.setBackgroundColor(0xffffffff);
    }
}
