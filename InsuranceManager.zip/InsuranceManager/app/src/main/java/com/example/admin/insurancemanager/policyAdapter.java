package com.example.admin.insurancemanager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class policyAdapter extends ArrayAdapter<policyData>{
	private int resourceId;
	public policyAdapter(Context context, int resource, ArrayList<policyData> objects) {
		super(context, resource, objects);
		resourceId=resource;
		//context activity  resource  �����ļ�  list��ʾ������
	}

public View getView(int position,View convertView,ViewGroup parent) {
	policyData policydata=getItem(position);	
	View view=LayoutInflater.from(getContext()).inflate(resourceId,null);
	TextView listview_policyid=(TextView)view.findViewById(R.id.listview_policyId);
	TextView listview_value=(TextView)view.findViewById(R.id.listview_value);
	TextView listview_place=(TextView)view.findViewById(R.id.listview_location);
	TextView listview_time=(TextView)view.findViewById(R.id.listview_time);

	listview_policyid.setText(policydata.getPolicyId());
	listview_place.setText(policydata.getPlace());
	listview_time.setText(policydata.getTime());
	if(policydata.getValue().equals("101"))
	{
		listview_value.setText("0-100");
	}
	else if(policydata.getValue().equals("102"))
	{
		listview_value.setText("101-1000");
	}
	else if(policydata.getValue().equals("103"))
	{
		listview_value.setText("1001-10000");
	}
	else if(policydata.getValue().equals("104"))
	{
		listview_value.setText("10000+");
	}
	return view;
	
}


	
	
}
