package com.example.admin.insurancemanager;

public class Policy
{
    private String id;
    private String time;
    private String date;
    private String description;
    private String remark;
    private String value;

    public Policy(String id, String time, String date, String description, String remark, String value)
    {
        this.id = id;
        this.time = time;
        this.date = date;
        this.description = description;
        this.remark = remark;
        this.value = value;
    }

    public String getId()
    {
        return id;
    }

    public String getTime()
    {
        return time;
    }

    public String getDate()
    {
        return date;
    }

    public String getDescription()
    {
        return description;
    }

    public String getRemark()
    {
        return remark;
    }

    public String getValue()
    {
        return value;
    }
}
