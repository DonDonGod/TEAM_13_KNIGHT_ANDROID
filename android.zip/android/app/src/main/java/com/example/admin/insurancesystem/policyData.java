package com.example.admin.insurancesystem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class policyData {
	private String policyName;
	private String policyId;
	private String state1;
	private String state2;
	private String state3;

	public policyData(String policyName, String policyid, String state)
	{
		this.policyName=policyName;
		this.policyId=policyid;

		String msg = state;
		ArrayList<String> stateList = new ArrayList<String>(Arrays.asList(msg.split("@@")));

		this.state1 = stateList.get(0);
		this.state2 = stateList.get(1);
		this.state3 = stateList.get(2);
	}
	public String getName() {
		return policyName;
	}
	public String getPolicyId() {
		return policyId;
	}
	public String getState1() {
		return state1;
	}
	public String getState2() {
		return state2;
	}
	public String getState3() {
		return state3;
	}
}
