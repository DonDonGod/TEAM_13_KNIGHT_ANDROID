package com.example.admin.insurancesystem;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;


public class MemuActivity extends AppCompatActivity
{
    private ImageButton btnMyPolicy;
    private ImageButton btnOnlineService;
    private ImageButton btnLostApply;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_interface);

        btnMyPolicy = (ImageButton) this.findViewById(R.id.imageButton1);
        btnOnlineService = (ImageButton) this.findViewById(R.id.imageButton2);
        btnLostApply = (ImageButton) this.findViewById(R.id.imageButton3);
    }

    public void My_policy(View v)
    {
        Intent intent = new Intent(MemuActivity.this, PolicyActivity.class);
        startActivity(intent);
    }

    public void Online_service(View v)
    {
        //Intent intent = new Intent(MemuActivity.this, .class);
        //startActivity(intent);
    }

    public void Lost_apply(View v)
    {
        Intent intent = new Intent(MemuActivity.this, ClaimActivity.class);
        startActivity(intent);
    }
}
