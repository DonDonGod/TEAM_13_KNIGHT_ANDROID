package com.example.admin.insurancesystem;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckPassword
{
    public static int checkPasswordStrength(String password)
    {
        int score = 0;
        System.out.println("score: " + score);

        //length
        int pwLen = password.length();
        if(pwLen <= 4)
        {
            score += 5;
        }
        else if(pwLen > 4 && pwLen <= 7)
        {
            score += 10;
        }
        else if(pwLen > 7)
        {
            score += 25;
        }
        System.out.println("score: " + score);

        //small character
        int scharacter = 0;
        for(int i = 0; i < password.length(); i++)
        {
            if(Character.isLowerCase(password.charAt(i)))
            {
                scharacter++;
            }
        }
        if(scharacter > 0 && scharacter <= 2)
        {
            score += 10;
        }
        else if(scharacter > 2)
        {
            score += 20;
        }
        System.out.println("score: " + score);

        //big character
        int bcharacter = 0;
        for(int i = 0; i < password.length(); i++)
        {
            if(Character.isUpperCase(password.charAt(i)))
            {
                bcharacter++;
            }
        }
        if(bcharacter > 0 && bcharacter <= 2)
        {
            score += 10;
        }
        else if(bcharacter > 2)
        {
            score += 20;
        }
        System.out.println("score: " + score);

        //number
        int number = 0;
        for(int i = 0; i < password.length(); i++)
        {
            if(Character.isDigit(password.charAt(i)))
            {
                number++;
            }
        }
        if(number > 0 && number <= 2)
        {
            score += 10;
        }
        else if(number > 2)
        {
            score += 20;
        }
        System.out.println("score: " + score);

        //signal
        int signal = 0;
        for(int i = 0; i < password.length(); i++)
        {
            if(!Character.isUpperCase(password.charAt(i)) && !Character.isLowerCase(password.charAt(i)) && !Character.isDigit(password.charAt(i)))
            {
                signal++;
            }
        }
        if(signal > 0 && signal <= 1)
        {
            score += 10;
        }
        else if(signal > 1)
        {
            score += 20;
        }
        System.out.println("Total score: " + score);

        return score;
    }
}
