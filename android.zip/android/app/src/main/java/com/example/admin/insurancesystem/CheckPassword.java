package com.example.admin.insurancesystem;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckPassword
{
    public static int checkPasswordStrength(String password)
    {
        int score = 0;

        //length
        int pwLen = password.length();
        if(pwLen <= 4)
        {
            score += 5;
        }
        else if(pwLen > 4 && pwLen <= 7)
        {
            score += 10;
        }
        else if(pwLen > 7)
        {
            score += 25;
        }

        //character
        Pattern r = Pattern.compile("([a-z])");
        Matcher m = r.matcher(password);
        if(m.find())
        {
            for(int i = 1; i <= m.groupCount(); i++)
            {

            }
        }

        return score;
    }
}
