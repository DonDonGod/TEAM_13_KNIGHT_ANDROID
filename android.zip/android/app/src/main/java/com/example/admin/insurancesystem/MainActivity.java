package com.example.admin.insurancesystem;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;

import java.util.Locale;

public class MainActivity extends AppCompatActivity
{
    private Button btnSignUp;
    private Button btnLogIn;

    public static boolean isEnglish = true;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSignUp = (Button) this.findViewById(R.id.btn_sign_up);
        btnLogIn = (Button) this.findViewById(R.id.btn_sign_in);
    }

    public void Sign_up(View v)
    {
        Intent intent = new Intent(MainActivity.this, SignUpActivity.class);
        startActivity(intent);
    }

    public void Log_in(View v)
    {
        Intent intent = new Intent(MainActivity.this, SignActivity.class);
        startActivity(intent);
    }

    public void Change_language(View v)
    {
        if(isEnglish)
        {
            //Locale myLocale = new Locale("zh_CN");
            Resources res = getResources();
            DisplayMetrics dm = res.getDisplayMetrics();
            Configuration conf = res.getConfiguration();
            conf.locale = Locale.SIMPLIFIED_CHINESE;
            res.updateConfiguration(conf, dm);
            isEnglish = false;
            recreate();
            System.out.println("Now is Chinese.");
        }
        else
        {
            //Locale myLocale = new Locale("en");
            Resources res = getResources();
            DisplayMetrics dm = res.getDisplayMetrics();
            Configuration conf = res.getConfiguration();
            conf.locale = Locale.ENGLISH;
            res.updateConfiguration(conf, dm);
            isEnglish = true;
            recreate();
            System.out.println("Now is English.");
        }
    }
}
