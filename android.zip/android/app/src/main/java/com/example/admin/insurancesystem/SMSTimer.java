package com.example.admin.insurancesystem;

import android.os.CountDownTimer;
import android.widget.Button;

public class SMSTimer extends CountDownTimer
{
    private Button btn;

    public SMSTimer(Button btn)
    {
        super(60*1000, 1000);
        this.btn = btn;
    }

    public void onTick(long millisUntilFinished)
    {
        btn.setText(millisUntilFinished / 1000 + "s");
    }

    public void onFinish()
    {
        btn.setText("Send");
        btn.setClickable(true);
    }
}
