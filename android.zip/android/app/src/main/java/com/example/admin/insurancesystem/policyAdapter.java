package com.example.admin.insurancesystem;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class policyAdapter extends ArrayAdapter<policyData>{
	private int resourceId;
	public policyAdapter(Context context, int resource,ArrayList<policyData> objects) {
		super(context, resource, objects);
		resourceId=resource;
		//context activity  resource  �����ļ�  list��ʾ������
	}

public View getView(int position,View convertView,ViewGroup parent) {
	policyData policydata=getItem(position);
	View view=LayoutInflater.from(getContext()).inflate(resourceId,null);
	TextView listview_name=(TextView)view.findViewById(R.id.listview_name);
	TextView listview_policyid=(TextView)view.findViewById(R.id.listview_policyId);
	TextView listview_state=(TextView)view.findViewById(R.id.listview_state);
	
	listview_name.setText(policydata.getName());
	listview_policyid.setText(policydata.getPolicyId());
	if(policydata.getState1().equals("0"))
	{
		listview_state.setText("Not Claimed");
	}
	else if(policydata.getState1().equals("1"))
	{
		listview_state.setText("Not Processed");
	}
	else if(policydata.getState1().equals("2"))
	{
		listview_state.setText("Processing");
	}
	else if(policydata.getState1().equals("3"))
	{
		listview_state.setText("Processed");
	}
	
	return view;
	
}


	
	
}
