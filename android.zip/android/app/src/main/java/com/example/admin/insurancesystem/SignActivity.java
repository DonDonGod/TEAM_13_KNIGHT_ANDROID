package com.example.admin.insurancesystem;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class SignActivity extends AppCompatActivity
{
    private EditText editPhone;
    private EditText editPassword;
    private EditText editID;
    private EditText editName;
    private Button btnSignin;
    private TextView textSignup;

    private String state;
    public static String PHONE;
    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 2)
            {
                if(state.equals("100"))
                {
                    progressDialog.cancel();
                    PHONE = editPhone.getText().toString();
                    Intent intent = new Intent(SignActivity.this, MemuActivity.class);
                    startActivity(intent);
                }
                else if(state.equals("200"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Phone number might be wrong. Please check again.",Toast.LENGTH_SHORT).show();
                }
                else if(state.equals("201"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Password might be wrong. Please check again.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                /*if(editPassword.getText().toString().equals("123456")) {
                    PHONE = editPhone.getText().toString();

                    Intent intent = new Intent(SignActivity.this, MemuActivity.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(),"Password might be wrong. Please check again.",Toast.LENGTH_SHORT).show();
                }*/
                if(!state.equals("100"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        editPhone = (EditText) this.findViewById(R.id.sign_in_et_username);
        editPassword = (EditText) this.findViewById(R.id.sign_in_et_password);
        editID = (EditText) this.findViewById(R.id.);
        editName = (EditText) this.findViewById(R.id.);
        btnSignin = (Button) this.findViewById(R.id.btn_sign_in);
        textSignup = (TextView) this.findViewById(R.id.tv_sign_in);
    }

    public void Sign_in(View v)
    {
        String phone = editPhone.getText().toString();
        String password = editPassword.getText().toString();

        if(phone.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Phone number can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if(password.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Password can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else
        {
            final JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("phone", phone);
                jsonObject.put("password", password);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Thread tread = new Thread(new Runnable() {
                @Override
                public void run() {
                    String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/user/login");
                    try
                    {
                        JSONObject getJsonObject = new JSONObject(str);
                        state = getJsonObject.getString("Checkcode");
                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                    System.out.println("The string get from server is: " + state);
                    Message msg = new Message();
                    msg.what = 2;
                    handler.sendMessage(msg);
                }
            });
            tread.start();

            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Please want......");
            progressDialog.setMessage("Signing in......");
            progressDialog.setIndeterminate(true);
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            Thread thread = new Thread()
            {
                public void run()
                {
                    try
                    {
                        sleep(10*1000);
                    }
                    catch(InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                    progressDialog.cancel();
                    Message msg = new Message();
                    msg.what = 101;
                    handler.sendMessage(msg);
                }
            };
            thread.start();
        }
    }

    public void Sign_up(View v)
    {
        Intent intent = new Intent(SignActivity.this, SignUpActivity.class);
        startActivity(intent);
    }

    /*

    public void UploadPersonalInfo(View v)
    {
        String id = editId.getText();
        String realname = editRealname.getText();
        String email = editEmail.getText();
        String photo = editPhoto.getText();
        String description = editDescription.getText();

        final JSONObject jsonObject = new JSONObject();
        try
        {
            jsonObject.put("phone", PHONE);
            jsonObject.put("id", id);
            jsonObject.put("realname", realname);
            jsonObject.put("email", email);
            jsonObject.put("photo", photo);
            jsonObject.put("description", description);
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
        Thread tread = new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/demo/login");
                System.out.println("The string get from server is: " + str);
                try
                {
                    JSONObject getJsonObject = new JSONObject(str);
                    state = getJsonObject.getString("state");

                    Message msg = new Message();
                    msg.what = 3;
                    handler.sendMessage(msg);
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
            }
        });
        tread.start();
    }

    public void DownloadPersonalInfo(View v)
    {
        final JSONObject jsonObject = new JSONObject();
        try
        {
            jsonObject.put("phone", PHONE);
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
        Thread tread = new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/demo/login");
                System.out.println("The string get from server is: " + str);
                try
                {
                    JSONObject getJsonObject = new JSONObject(str);
                    id = getJsonObject.getString("id");
                    realname = getJsonObject.getString("realname");
                    email = getJsonObject.getString("email");
                    photo = getJsonObject.getString("photo");
                    description = getJsonObject.getString("description");

                    Message msg = new Message();
                    msg.what = 4;
                    handler.sendMessage(msg);
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
            }
        });
        tread.start();
    }

    public void UploadClaim(View v)
    {

    }

    public void DownloadClaim(View v)
    {
        final JSONObject jsonObject = new JSONObject();
        try
        {
            jsonObject.put("phone", PHONE);
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
        Thread tread = new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/demo/login");
                System.out.println("The string get from server is: " + str);
                try
                {
                    JSONObject getJsonObject = new JSONObject(str);
                    claimTime = getJsonObject.getString("claimTime");
                    claimThing = getJsonObject.getString("claimThing");
                    claimType = getJsonObject.getString("claimType");
                    claimPhoto = getJsonObject.getString("claimPhoto");
                    claimDescription = getJsonObject.getString("claimDescription");
                    claimPlace = getJsonObject.getString("claimPlace");
                    claimValue = getJsonObject.getString("claimValue");

                    Message msg = new Message();
                    msg.what = 6;
                    handler.sendMessage(msg);
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
            }
        });
        tread.start();
    }*/

    /*private String PostConnection()
    {
        URL url = null;
        HttpURLConnection conn = null;
        StringBuffer stringBuffer = null;

        try
        {
            url = new URL("http://101.132.96.76:8080/person/save?name=Don");
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(1000);//time out
            conn.setDoInput(true);//can read
            conn.setDoOutput(true);//can write
            conn.setRequestMethod("POST");
            conn.connect();


            OutputStream outputStream = conn.getOutputStream();
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);


            bufferedWriter.write("Hello!This is Don!");
            bufferedWriter.flush();


            bufferedWriter.close();
            outputStreamWriter.close();
            outputStream.close();


            InputStream inputStream = conn.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);


            stringBuffer = new StringBuffer();
            String temp = null;
            while((temp = bufferedReader.readLine()) != null)
            {
                stringBuffer.append(temp);
            }


            bufferedReader.close();
            inputStreamReader.close();
            inputStream.close();
        }
        catch(MalformedURLException e)
        {
            e.printStackTrace();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            conn.disconnect();
        }

        return stringBuffer.toString();
    }*/


    /*private void Decode(String str)
    {
        System.out.println("The string get from server is: " + str);
        try
        {
            JSONObject jsonObject = new JSONObject(str);
            int type = jsonObject.getInt("type");

            if(type == 1)
            {
                state = jsonObject.getString("state");

                Message msg = new Message();
                msg.what = 1;
                handler.sendMessage(msg);
            }
            else if(type == 2)
            {
                state = jsonObject.getString("state");

                Message msg = new Message();
                msg.what = 2;
                handler.sendMessage(msg);
            }
            else if(type == 3)
            {
                state = jsonObject.getString("state");

                Message msg = new Message();
                msg.what = 3;
                handler.sendMessage(msg);
            }
            else if(type == 4)
            {
                id = jsonObject.getString("id");
                realname = jsonObject.getString("realname");
                email = jsonObject.getString("email");
                photo = jsonObject.getString("photo");
                description = jsonObject.getString("description");

                Message msg = new Message();
                msg.what = 4;
                handler.sendMessage(msg);
            }
            else if(type == 5)
            {
                state = jsonObject.getString("state");

                Message msg = new Message();
                msg.what = 5;
                handler.sendMessage(msg);
            }
            else if(type == 6)
            {
                claimTime = jsonObject.getString("claimTime");
                claimThing = jsonObject.getString("claimThing");
                claimType = jsonObject.getString("claimType");
                claimPhoto = jsonObject.getString("claimPhoto");
                claimDescription = jsonObject.getString("claimDescription");
                claimPlace = jsonObject.getString("claimPlace");
                claimValue = jsonObject.getString("claimValue");

                Message msg = new Message();
                msg.what = 6;
                handler.sendMessage(msg);
            }
        }
        catch(JSONException e)
        {
            e.printStackTrace();
        }
    }*/
}
