package com.example.admin.insurancesystem;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;

public class DetailActivity extends AppCompatActivity
{
    private EditText editPolicyID;
    private EditText editPolicyName;
    private EditText editPhone;
    private EditText editTime;
    private EditText editPlace;
    private EditText editDescription;
    private EditText editValue;
    private TextView textPhoto;
    private ImageView imgState1;
    private RadioGroup rgState1;
    private RadioButton rgState1_2;
    private RadioButton rgState1_3;
    private RadioGroup rgState2;
    private RadioButton rgState2_0;
    private RadioButton rgState2_1;
    private RadioButton rgState2_2;
    private RadioGroup rgState3;
    private RadioButton rgState3_0;
    private RadioButton rgState3_1;
    private RadioButton rgState3_2;
    private TextView textFeedback1;
    private TextView textFeedback2;
    private TextView textFeedback3;
    private Button btnEdit;
    private ImageView btnBack;

    private String policyID;
    private String policyName;
    private String phone;
    private String time;
    private String place;
    private String description;
    private String value;
    ////////////private String photo;
    private String claimState1 = "0";
    private String claimState2 = "0";
    private String claimState3 = "0";
    private String feedback1 = "xxxx";
    private String feedback2 = "xxxx";
    private String feedback3 = "xxxx";
    private String state = "";
    private String message = "";
    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 6)
            {
                if(state.equals("100"))
                {
                    progressDialog.cancel();
                    editPolicyID.setText(policyID);
                    editPolicyName.setText(policyName);
                    editPhone.setText(phone);
                    editTime.setText(time);
                    editPlace.setText(place);
                    editDescription.setText(description);
                    if (value.equals("101"))
                    {
                        editValue.setText("0-100");
                    }
                    else if (value.equals("102"))
                    {
                        editValue.setText("100-1000");
                    }
                    else if (value.equals("103"))
                    {
                        editValue.setText("1000-10000");
                    }
                    else if (value.equals("104"))
                    {
                        editValue.setText("10000+");
                    }

                    ////////////////imgPhoto.setImageDrawable(photo);

                    if(!feedback1.equals("xxxx"))
                    {
                        textFeedback1.setText(feedback1);
                    }
                    if(!feedback2.equals("xxxx"))
                    {
                        textFeedback2.setText(feedback2);
                    }
                    if(!feedback3.equals("xxxx"))
                    {
                        textFeedback3.setText(feedback3);
                    }

                    if(claimState1.equals("1"))
                    {
                        imgState1.setImageResource(R.drawable.step123_1);
                    }
                    else if(claimState1.equals("2"))
                    {
                        imgState1.setImageResource(R.drawable.step123_2);
                    }
                    else if(claimState1.equals("3"))
                    {
                        imgState1.setImageResource(R.drawable.step123_3);
                    }

                    if((claimState1.equals("3") && claimState2.equals("0") && claimState3.equals("0")) || (claimState1.equals("1") && claimState2.equals("0") && claimState3.equals("0")))
                    {
                        rgState1.check(rgState1_3.getId());
                    }
                    else
                    {
                        rgState1.check(rgState1_2.getId());
                    }

                    if(claimState2.equals("0"))
                    {
                        rgState2.check(rgState2_0.getId());
                    }
                    else if(claimState2.equals("1"))
                    {
                        rgState2.check(rgState2_1.getId());
                    }
                    else if(claimState2.equals("2"))
                    {
                        rgState2.check(rgState2_2.getId());
                    }

                    if(claimState3.equals("0"))
                    {
                        rgState3.check(rgState3_0.getId());
                    }
                    else if(claimState3.equals("1"))
                    {
                        rgState3.check(rgState3_1.getId());
                    }
                    else if(claimState3.equals("2"))
                    {
                        rgState3.check(rgState3_2.getId());
                    }
                }
                else if(state.equals("200"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Something wrong. Please try again.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(!state.equals("100"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.policy_details);

        editPolicyID = (EditText) findViewById(R.id.policyNumber_input);
        editPolicyName = (EditText)findViewById(R.id.policyName_Input);
        editPhone = (EditText)findViewById(R.id.policyPhone_Input);
        editTime = (EditText)findViewById(R.id.policyTime_Input);
        editPlace = (EditText)findViewById(R.id.policyLocation_Input);
        editDescription = (EditText)findViewById(R.id.policyReason_Input);
        editValue = (EditText)findViewById(R.id.policyPrice_Input);
        textPhoto = (TextView)findViewById(R.id.detail_textView1);
        imgState1 = (ImageView) findViewById(R.id.Detail_imageView2);
        rgState1 = (RadioGroup) findViewById(R.id.application_accept_group);
        rgState1_2 = (RadioButton) findViewById(R.id.application_accept_yes);
        rgState1_3 = (RadioButton) findViewById(R.id.application_accept_no);
        rgState2 = (RadioGroup) findViewById(R.id.find_package);
        rgState2_0 = (RadioButton) findViewById(R.id.find_package_unsure);
        rgState2_1 = (RadioButton) findViewById(R.id.find_package_no);
        rgState2_2 = (RadioButton) findViewById(R.id.find_package_yes);
        rgState3 = (RadioGroup) findViewById(R.id.if_paid);
        rgState3_0 = (RadioButton) findViewById(R.id.if_paid_unsure);
        rgState3_1 = (RadioButton) findViewById(R.id.if_paid_no);
        rgState3_2 = (RadioButton) findViewById(R.id.if_paid_yes);
        textFeedback1 = (TextView)findViewById(R.id.application_accept_feedback);
        textFeedback2 = (TextView)findViewById(R.id.findpackage_feedback);
        textFeedback3 = (TextView)findViewById(R.id.claim_feedback);
        btnEdit = (Button) findViewById(R.id.detail_modify);
        btnBack = (ImageView) findViewById(R.id.detail_back);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        policyID = bundle.getString("policyID");




        /*policyID = "123123";
        try
        {
            String str = "{\"Checkcode\":\"100\",\"Message\":{\"policy_number\":\"123\",\"policy_name\":\"xxxxxxxxxxxxx\",\"phone_number\":\"13123456789\",\"time\":\"yyyy/mm/dd/hh/mm\",\"place\":\"xxxx\",\"reason\":\"xxxxxxxxxxxxxxxxx\",\"price\":\"101\",\"picture\":\"x0123412edx3\",\"feedback\":\"xxx123xxx@@xxxxxxxxceqwdsax@@asdasd\",\"claim_states\": \"2@@2@@0\"}}";
            JSONObject getMsg = new JSONObject(str);
            state = getMsg.getString("Checkcode");
            message = getMsg.getString("Message");

            JSONObject getJsonObject = new JSONObject(message);
            policyName = getJsonObject.getString("policy_name");
            phone = getJsonObject.getString("phone_number");
            time = getJsonObject.getString("time");
            place = getJsonObject.getString("place");
            description = getJsonObject.getString("reason");
            value = getJsonObject.getString("price");
            ///////////photo = getJsonObject.getString("picture");

            String msgFeedback = getJsonObject.getString("feedback");
            ArrayList<String> feedbackList = new ArrayList<String>(Arrays.asList(msgFeedback.split("@@")));
            feedback1 = feedbackList.get(0);
            feedback2 = feedbackList.get(1);
            feedback3 = feedbackList.get(2);

            String msgState = getJsonObject.getString("claim_states");
            ArrayList<String> stateList = new ArrayList<String>(Arrays.asList(msgState.split("@@")));
            claimState1 = stateList.get(0);
            claimState2 = stateList.get(1);
            claimState3 = stateList.get(2);
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
        Message msg = new Message();
        msg.what = 6;
        handler.sendMessage(msg);*/




        final JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("policy_number", policyID);
            System.out.println(jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Thread tread = new Thread(new Runnable() {
            @Override
            public void run() {
                String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/user/lost_luggage/receive");
                System.out.println("The string get from server is: " + str);
                try
                {
                    JSONObject getMsg = new JSONObject(str);
                    state = getMsg.getString("Checkcode");
                    message = getMsg.getString("Message");

                    try
                    {
                        JSONObject getJsonObject = new JSONObject(message);
                        policyName = getJsonObject.getString("policy_name");
                        phone = getJsonObject.getString("phone_number");
                        time = getJsonObject.getString("time");
                        place = getJsonObject.getString("place");
                        description = getJsonObject.getString("reason");
                        value = getJsonObject.getString("price");
                        ///////////photo = getJsonObject.getString("picture");

                        String msgFeedback = getJsonObject.getString("feedback");
                        ArrayList<String> feedbackList = new ArrayList<String>(Arrays.asList(msgFeedback.split("@@")));
                        feedback1 = feedbackList.get(0);
                        feedback2 = feedbackList.get(1);
                        feedback3 = feedbackList.get(2);

                        String msgState = getJsonObject.getString("states");
                        ArrayList<String> stateList = new ArrayList<String>(Arrays.asList(msgState.split("@@")));
                        claimState1 = stateList.get(0);
                        claimState2 = stateList.get(1);
                        claimState3 = stateList.get(2);

                        System.out.println("--------------"+ claimState1 + "----------------");
                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
                Message msg = new Message();
                msg.what = 6;
                handler.sendMessage(msg);
            }
        });
        tread.start();

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please want......");
        progressDialog.setMessage("Loading......");
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        Thread thread = new Thread()
        {
            public void run()
            {
                try
                {
                    sleep(10*1000);
                }
                catch(InterruptedException e)
                {
                    e.printStackTrace();
                }
                progressDialog.cancel();
                Message msg = new Message();
                msg.what = 101;
                handler.sendMessage(msg);
            }
        };
        thread.start();
    }

    public void Edit(View v)
    {
        Intent intent = new Intent(DetailActivity.this, ClaimActivity.class);
        intent.putExtra("edit_policyID", policyID);
        intent.putExtra("edit_policyName", policyName);
        intent.putExtra("edit_phone", phone);
        intent.putExtra("edit_place", place);
        intent.putExtra("edit_description", description);
        intent.putExtra("edit_value", value);
        intent.putExtra("isEdit", true);
        startActivity(intent);
    }

    public void Back(View v)
    {
        finish();
    }
}
