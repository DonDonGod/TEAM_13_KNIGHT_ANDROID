package com.example.admin.insurancesystem;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class ForgetActivity extends AppCompatActivity
{
    private EditText editPhone;
    private EditText editCode;
    private Button btnNext;
    private Button btnVerify;

    private String state;
    private String SMSPhone = "1314520";
    private String SMSCode = "1314520";
    private SMSTimer timer = null;
    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 1)
            {
                if(state.equals("Success"))
                {
                    progressDialog.cancel();
                    Intent intent = new Intent(ForgetActivity.this, NewpasswordActivity.class);
                    startActivity(intent);
                }
                else if(state.equals("No phone exists"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Phone number has already existed. Please sign in or change another one.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(!state.equals("Success"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.);

        editPhone = (EditText) this.findViewById(R.id.);
        editCode = (EditText) this.findViewById(R.id.);
        btnNext = (Button) this.findViewById(R.id.);
        btnVerify = (Button) this.findViewById(R.id.);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        if(timer != null)
        {
            timer.cancel();
            timer = null;
        }
    }

    public void Verify(View v)
    {
        if(editPhone.getText().toString().equals(""))
        {
            Toast.makeText(getApplicationContext(),"Phone number can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else
        {
            SMSPhone = editPhone.getText().toString();

            System.out.println("Send code!!!!");
            Thread tread = new Thread(new Runnable()
            {
                @Override
                public void run()
                {
                    try
                    {
                        String getMsg = SendCode.sendMsg(editPhone.getText().toString());
                        System.out.println(getMsg);
                        JSONObject jsonObject = new JSONObject(getMsg);
                        SMSCode = jsonObject.getString("obj");
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
            });
            tread.start();

            btnVerify.setClickable(false);
            timer = new SMSTimer(btnVerify);
            timer.start();
        }
    }

    public void Next(View v)
    {
        String phone = editPhone.getText().toString();
        String code = editCode.getText().toString();

        if(phone.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Phone number can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if(code.equals(""))
        {
            Toast.makeText(getApplicationContext(),"SMS code can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if(!phone.equals(SMSPhone) || !code.equals(SMSCode))
        {
            Toast.makeText(getApplicationContext(),"SMS code is wrong. Please check again.",Toast.LENGTH_SHORT).show();
        }
        else
        {
            final JSONObject jsonObject = new JSONObject();
            try
            {
                jsonObject.put("phone", phone);
                System.out.println(jsonObject.toString());
            }
            catch (JSONException e)
            {
                e.printStackTrace();
            }
            Thread tread = new Thread(new Runnable()
            {
                @Override
                public void run()
                {
                    String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/user/register");
                    System.out.println("The string get from server is: " + str);
                    state = str;
                    Message msg = new Message();
                    msg.what = 1;
                    handler.sendMessage(msg);
                }
            });
            tread.start();

            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Please want......");
            progressDialog.setMessage("Checking phone number......");
            progressDialog.setIndeterminate(true);
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            Thread thread = new Thread()
            {
                public void run()
                {
                    try
                    {
                        sleep(10*1000);
                    }
                    catch(InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                    progressDialog.cancel();
                    Message msg = new Message();
                    msg.what = 101;
                    handler.sendMessage(msg);
                }
            };
            thread.start();
        }
    }
}
