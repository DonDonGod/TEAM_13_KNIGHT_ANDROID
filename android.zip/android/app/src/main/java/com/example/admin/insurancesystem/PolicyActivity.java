package com.example.admin.insurancesystem;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class PolicyActivity extends AppCompatActivity
{
    ListView listview;
    SwipeRefreshLayout srl;

    private String state = "";
    private String message = "";
    private ProgressDialog progressDialog = null;
    private JSONArray arrayList = null;
    private ArrayList<policyData> policylist;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 6)
            {
                if(state.equals("100"))
                {
                    progressDialog.cancel();
                    policyAdapter adapter = new policyAdapter(PolicyActivity.this, R.layout.layout_listview, policylist);
                    listview.setAdapter(adapter);
                }
                else if(state.equals("200"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Something wrong. Please try again.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(!state.equals("100"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_policy);

        listview = (ListView) findViewById(R.id.policy_listview);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
            {
                if(!policylist.get(i).getState1().equals("0"))
                {
                    Intent intent = new Intent(PolicyActivity.this, DetailActivity.class);
                    intent.putExtra("policyID", policylist.get(i).getPolicyId());
                    startActivity(intent);
                }
            }
        });

        srl = (SwipeRefreshLayout) findViewById(R.id.swipe_ly);
        srl.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh()
            {
                final JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("phone_number", SignActivity.PHONE);
                    System.out.println(jsonObject.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Thread tread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/user/policy/list");
                        System.out.println("The string get from server is: " + str);
                        try
                        {
                            JSONObject getMsg = new JSONObject(str);
                            state = getMsg.getString("Checkcode");
                            message = getMsg.getString("Message");

                            arrayList = new JSONArray(message);
                            System.out.println(arrayList.toString());
                            try
                            {
                                policylist = new ArrayList<policyData>();
                                for(int i = 0; i < arrayList.length(); i++)
                                {
                                    JSONObject jsob = new JSONObject(arrayList.get(i).toString());
                                    policylist.add(new policyData(jsob.getString("policy_name"), jsob.getString("policy_number"), jsob.getString("states")));
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }

                        Message msg = new Message();
                        msg.what = 6;
                        handler.sendMessage(msg);
                        if(srl.isRefreshing())
                        {
                            srl.setRefreshing(false);
                        }
                    }
                });
                tread.start();

                progressDialog = new ProgressDialog(PolicyActivity.this);
                progressDialog.setTitle("Please wait......");
                progressDialog.setMessage("Loading......");
                progressDialog.setIndeterminate(true);
                progressDialog.setCancelable(false);
                progressDialog.setCanceledOnTouchOutside(false);
                progressDialog.show();
                Thread thread = new Thread()
                {
                    public void run()
                    {
                        try
                        {
                            sleep(10*1000);
                        }
                        catch(InterruptedException e)
                        {
                            e.printStackTrace();
                        }
                        progressDialog.cancel();
                        state = "";
                        Message msg = new Message();
                        msg.what = 101;
                        handler.sendMessage(msg);
                        if(srl.isRefreshing())
                        {
                            srl.setRefreshing(false);
                        }
                    }
                };
                thread.start();
            }
        });

        policylist = new ArrayList<policyData>();


        /*String str = "{\"Checkcode\":\"100\",\"Message\":[{\"policy_number\":\"123\",\"policy_name\":\"xxxxxxxxxxxxx\",\"time\":\"yyyy/mm/dd/hh/mm\",\"claim_states\":\"1@@0@@0\"},{\"policy_number\":\"666\",\"policy_name\":\"yyyyy\",\"time\":\"yyyy/mm/dd/hh/mm\",\"claim_states\":\"2@@1@@0\"}]}";
        try {
            JSONObject getMsg = new JSONObject(str);
            state = getMsg.getString("Checkcode");
            message = getMsg.getString("Message");
            arrayList = new JSONArray(message);
            System.out.println("Now is: " + message);
            System.out.println("Array " + arrayList.get(0).toString());
            System.out.println("Array " + arrayList.get(1).toString());
            for(int i = 0; i < arrayList.length(); i++)
            {
                JSONObject jsob = new JSONObject(arrayList.get(i).toString());
                System.out.println("1: " + jsob.getString("policy_name"));
                System.out.println("2: " + jsob.getString("policy_number"));
                System.out.println("3: " + jsob.getString("claim_states"));
                System.out.println("4: " + jsob.getString("time"));
                policylist.add(new policyData(jsob.getString("policy_name"), jsob.getString("policy_number"), jsob.getString("claim_states"), jsob.getString("time")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Message msg = new Message();
        msg.what = 6;
        handler.sendMessage(msg);*/




        final JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("phone_number", SignActivity.PHONE);
            System.out.println(jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Thread tread = new Thread(new Runnable() {
            @Override
            public void run() {
                String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/user/policy/list");
                System.out.println("The string get from server is: " + str);
                try
                {
                    JSONObject getMsg = new JSONObject(str);
                    state = getMsg.getString("Checkcode");
                    message = getMsg.getString("Message");

                    arrayList = new JSONArray(message);
                    System.out.println(arrayList.toString());
                    try
                    {
                        policylist = new ArrayList<policyData>();
                        for(int i = 0; i < arrayList.length(); i++)
                        {
                            JSONObject jsob = new JSONObject(arrayList.get(i).toString());
                            policylist.add(new policyData(jsob.getString("policy_name"), jsob.getString("policy_number"), jsob.getString("states")));
                        }
                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }

                Message msg = new Message();
                msg.what = 6;
                handler.sendMessage(msg);
            }
        });
        tread.start();

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please want......");
        progressDialog.setMessage("Loading......");
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        Thread thread = new Thread()
        {
            public void run()
            {
                try
                {
                    sleep(10*1000);
                }
                catch(InterruptedException e)
                {
                    e.printStackTrace();
                }
                progressDialog.cancel();
                Message msg = new Message();
                msg.what = 101;
                handler.sendMessage(msg);
            }
        };
        thread.start();
    }


    public void Back(View v)
    {
        finish();
    }
}
