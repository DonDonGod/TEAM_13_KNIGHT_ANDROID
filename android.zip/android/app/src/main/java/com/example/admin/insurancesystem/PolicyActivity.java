package com.example.admin.insurancesystem;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TabHost;

public class PolicyActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_policy);

        TabHost tab = (TabHost) findViewById(android.R.id.tabhost);
        tab.setup();

        tab.addTab(tab.newTabSpec("tab1").setIndicator("ALL", null).setContent(R.id.tab1));
        tab.addTab(tab.newTabSpec("tab2").setIndicator("Validity", null).setContent(R.id.tab2));
        tab.addTab(tab.newTabSpec("tab3").setIndicator("Overdue", null).setContent(R.id.tab3));
    }
}
