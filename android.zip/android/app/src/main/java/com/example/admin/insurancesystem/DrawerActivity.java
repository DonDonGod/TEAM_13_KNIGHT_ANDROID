package com.example.admin.insurancesystem;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;

public class DrawerActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener
{
    private Toolbar toolbar;
    private DrawerLayout drawer;
    private NavigationView navigationView;
    private TextView textPhone;
    private TextView textId;
    private TextView textName;

    private String state = "";
    private String message = "";
    private String personId;
    private String fullName;
    private String emailAddress;
    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 6)
            {
                if(state.equals("100"))
                {
                    progressDialog.cancel();
                    textPhone.setText(SignActivity.PHONE);
                    textId.setText(personId);
                    textName.setText(fullName);
                    navigationView.getMenu().getItem(1).setTitle(emailAddress);
                }
                else if(state.equals("200"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"This user does not exist.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(!state.equals("100"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_interface_new);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        textPhone = (TextView) navigationView.getHeaderView(0).findViewById(R.id.side_phoneNumber);
        textId = (TextView) navigationView.getHeaderView(0).findViewById(R.id.side_id);
        textName = (TextView) navigationView.getHeaderView(0).findViewById(R.id.side_username);

        //tutorial
        SharedPreferences sharedPreferences = this.getSharedPreferences("share6",MODE_PRIVATE);//!!!!!!!!!!!!!!!!!!!!!!!!!
        boolean isNew = sharedPreferences.getBoolean("isNew", true);
        if(isNew)
        {
            final Dialog dialog1 = new Dialog(DrawerActivity.this, R.style.edit_AlertDialog_style);
            ImageView mImageView = getImageView(R.drawable.guidance_email);
            mImageView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    dialog1.dismiss();

                    final Dialog dialog2 = new Dialog(DrawerActivity.this, R.style.edit_AlertDialog_style);
                    ImageView mImageView = getImageView(R.drawable.guidance_password);
                    mImageView.setOnClickListener(new View.OnClickListener()
                    {
                        @Override
                        public void onClick(View v)
                        {
                            dialog2.dismiss();

                            final Dialog dialog3 = new Dialog(DrawerActivity.this, R.style.edit_AlertDialog_style);
                            ImageView mImageView = getImageView(R.drawable.guidance_language);
                            mImageView.setOnClickListener(new View.OnClickListener()
                            {
                                @Override
                                public void onClick(View v)
                                {
                                    dialog3.dismiss();

                                    final Dialog dialog4 = new Dialog(DrawerActivity.this, R.style.edit_AlertDialog_style);
                                    ImageView mImageView = getImageView(R.drawable.guidance_log_out);
                                    mImageView.setOnClickListener(new View.OnClickListener()
                                    {
                                        @Override
                                        public void onClick(View v)
                                        {
                                            dialog4.dismiss();

                                            final Dialog dialog5 = new Dialog(DrawerActivity.this, R.style.edit_AlertDialog_style);
                                            ImageView mImageView = getImageView(R.drawable.guidance2_policy);
                                            mImageView.setOnClickListener(new View.OnClickListener()
                                            {
                                                @Override
                                                public void onClick(View v)
                                                {
                                                    dialog5.dismiss();

                                                    final Dialog dialog6 = new Dialog(DrawerActivity.this, R.style.edit_AlertDialog_style);
                                                    ImageView mImageView = getImageView(R.drawable.guidance2_apply);
                                                    mImageView.setOnClickListener(new View.OnClickListener()
                                                    {
                                                        @Override
                                                        public void onClick(View v)
                                                        {
                                                            dialog6.dismiss();
                                                        }
                                                    });
                                                    dialog6.setContentView(mImageView);
                                                    dialog6.setCanceledOnTouchOutside(false);
                                                    dialog6.show();
                                                }
                                            });
                                            dialog5.setContentView(mImageView);
                                            dialog5.setCanceledOnTouchOutside(false);
                                            dialog5.show();
                                        }
                                    });
                                    dialog4.setContentView(mImageView);
                                    dialog4.setCanceledOnTouchOutside(false);
                                    dialog4.show();
                                }
                            });
                            dialog3.setContentView(mImageView);
                            dialog3.setCanceledOnTouchOutside(false);
                            dialog3.show();
                        }
                    });
                    dialog2.setContentView(mImageView);
                    dialog2.setCanceledOnTouchOutside(false);
                    dialog2.show();
                }
            });
            dialog1.setContentView(mImageView);
            dialog1.setCanceledOnTouchOutside(false);
            dialog1.show();

            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putBoolean("isNew", false);
            editor.commit();
        }
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        Refresh_info();
    }

    @Override
    public void onBackPressed()
    {
        drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onNavigationItemSelected(MenuItem item)
    {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.side_email_content)
        {
            Intent intent = new Intent(DrawerActivity.this, ChangeEmailActivity.class);
            startActivity(intent);
        }
        else if (id == R.id.side_password_content)
        {
            Intent intent = new Intent(DrawerActivity.this, ChangePasswordActivity.class);
            startActivity(intent);
        }
        else if (id == R.id.side_setting)
        {
            //change language
            if(MainActivity.isEnglish)
            {
                //Locale myLocale = new Locale("zh_CN");
                Resources res = getResources();
                DisplayMetrics dm = res.getDisplayMetrics();
                Configuration conf = res.getConfiguration();
                conf.locale = Locale.SIMPLIFIED_CHINESE;
                res.updateConfiguration(conf, dm);
                MainActivity.isEnglish = false;
                recreate();
                System.out.println("Now is Chinese.");
            }
            else
            {
                //Locale myLocale = new Locale("en");
                Resources res = getResources();
                DisplayMetrics dm = res.getDisplayMetrics();
                Configuration conf = res.getConfiguration();
                conf.locale = Locale.ENGLISH;
                res.updateConfiguration(conf, dm);
                MainActivity.isEnglish = true;
                recreate();
                System.out.println("Now is English.");
            }
        }
        else if (id == R.id.side_exit)
        {
            Intent intent = new Intent(DrawerActivity.this, MainActivity.class);
            startActivity(intent);
        }

        drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void My_policy(View v)
    {
        Intent intent = new Intent(DrawerActivity.this, PolicyActivity.class);
        startActivity(intent);
    }

    public void Lost_apply(View v)
    {
        Intent intent = new Intent(DrawerActivity.this, ClaimActivity.class);
        intent.putExtra("isEdit", false);
        startActivity(intent);
    }

    private void Refresh_info()
    {
        final JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("phone_number", SignActivity.PHONE);
            System.out.println(jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Thread tread = new Thread(new Runnable() {
            @Override
            public void run()
            {
                String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/user/personal_information/pi");
                System.out.println("The string get from server is: " + str);
                try
                {
                    JSONObject getMsg = new JSONObject(str);
                    state = getMsg.getString("Checkcode");
                    message = getMsg.getString("Message");

                    try
                    {
                        JSONObject getJsonObject = new JSONObject(message);
                        personId = getJsonObject.getString("id_number");
                        fullName = getJsonObject.getString("fullname");
                        emailAddress = getJsonObject.getString("email");
                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
                Message msg = new Message();
                msg.what = 6;
                handler.sendMessage(msg);
            }
        });
        tread.start();

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please wait......");
        progressDialog.setMessage("Loading......");
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        Thread thread = new Thread()
        {
            public void run()
            {
                try
                {
                    sleep(10*1000);
                }
                catch(InterruptedException e)
                {
                    e.printStackTrace();
                }
                progressDialog.cancel();
                Message msg = new Message();
                msg.what = 101;
                handler.sendMessage(msg);
            }
        };
        thread.start();
    }

    private ImageView getImageView(int photo)
    {
        ImageView iv = new ImageView(this);
        //宽高
        iv.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        //设置Padding
        iv.setPadding(20,20,20,20);
        //imageView设置图片
        iv.setImageResource(photo);
        return iv;
    }
}
