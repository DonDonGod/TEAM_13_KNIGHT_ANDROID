package com.example.admin.insurancesystem;

public class Policy
{
    private String id;
    private String name;
    private String phone;
    private String time;
    private String place;
    private String description;
    private String remark;
    private String value;
    private String photo;
    private String state;

    public Policy(String id, String name, String phone, String time, String place, String description, String remark, String value, String photo, String state)
    {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.time = time;
        this.place = place;
        this.description = description;
        this.remark = remark;
        this.value = value;
        this.photo = photo;
        this.state = state;
    }

    public String getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public String getPhone()
    {
        return phone;
    }

    public String getTime()
    {
        return time;
    }

    public String getPlace()
    {
        return place;
    }

    public String getDescription()
    {
        return description;
    }

    public String getRemark()
    {
        return remark;
    }

    public String getValue()
    {
        return value;
    }

    public String getPhoto()
    {
        return photo;
    }

    public String getState()
    {
        return state;
    }
}
