package com.example.admin.insurancesystem;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class ChangeEmailActivity  extends AppCompatActivity
{
    private EditText editEmail;
    private EditText editSMS;
    private Button btnChange;
    private Button btnVerify;
    private ImageView btnBack;

    private String state = "";
    private String SMSEmail = "1314520";
    private String SMSCode = "1314520";
    private SMSTimer timer = null;
    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if(msg.what == 1)
            {
                if(state.equals("100"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Succeed!",Toast.LENGTH_SHORT).show();
                    finish();
                }
                else if(state.equals("200"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Something wrong with the server. Please try it later.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(!state.equals("100"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_email);

        editEmail = (EditText) this.findViewById(R.id.change_email_address);
        editSMS = (EditText) this.findViewById(R.id.change_email_sms);
        btnChange = (Button) this.findViewById(R.id.dirry_nmsl);
        btnVerify = (Button) this.findViewById(R.id.change_email_send);
        btnBack = (ImageView) this.findViewById(R.id.change_email_back);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        if(timer != null)
        {
            timer.cancel();
            timer = null;
        }
    }

    public void Verify(View v)
    {
        if(editEmail.getText().toString().equals(""))
        {
            Toast.makeText(getApplicationContext(),"Email number can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else
        {
            SMSEmail = editEmail.getText().toString();

            System.out.println("Send email code!!!!");
            Thread tread = new Thread(new Runnable()
            {
                @Override
                public void run()
                {
                    try
                    {
                        SMSCode = SendEmail.sendEmail(editEmail.getText().toString());
                        System.out.println(SMSCode);
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
            });
            tread.start();

            btnVerify.setClickable(false);
            timer = new SMSTimer(btnVerify);
            timer.start();
        }
    }

    public void Change(View v)
    {
        String email = editEmail.getText().toString();
        String code = editSMS.getText().toString();

        if(email.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Email can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if(code.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Verify code can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if(!email.equals(SMSEmail) || !code.equals(SMSCode))
        {
            Toast.makeText(getApplicationContext(),"Verify code is wrong. Please check again.",Toast.LENGTH_SHORT).show();
        }
        else
        {
            final JSONObject jsonObject = new JSONObject();
            try
            {
                jsonObject.put("phone_number", SignActivity.PHONE);
                jsonObject.put("email", email);
                System.out.println(jsonObject.toString());
            }
            catch (JSONException e)
            {
                e.printStackTrace();
            }
            Thread tread = new Thread(new Runnable()
            {
                @Override
                public void run()
                {
                    String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/user/personal_information/ci");
                    System.out.println("The string get from server is: " + str);
                    try
                    {
                        JSONObject getJsonObject = new JSONObject(str);
                        state = getJsonObject.getString("Checkcode");
                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                    Message msg = new Message();
                    msg.what = 1;
                    handler.sendMessage(msg);
                }
            });
            tread.start();

            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Please want......");
            progressDialog.setMessage("Updating email......");
            progressDialog.setIndeterminate(true);
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            Thread thread = new Thread()
            {
                public void run()
                {
                    try
                    {
                        sleep(10*1000);
                    }
                    catch(InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                    progressDialog.cancel();
                    Message msg = new Message();
                    msg.what = 101;
                    handler.sendMessage(msg);
                }
            };
            thread.start();
        }
    }

    public void Back(View v)
    {
        finish();
    }
}