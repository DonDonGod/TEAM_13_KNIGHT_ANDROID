package com.example.admin.insurancesystem;

public class Information
{
    public String username;
    public String password;

    public Information(String username, String password)
    {
        this.username = username;
        this.password = password;
    }

    public String getUsername()
    {
        return username;
    }

    public String getPassword()
    {
        return password;
    }
}
