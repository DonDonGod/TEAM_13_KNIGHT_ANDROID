package com.example.admin.insurancesystem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Date;


public class SendCode
{
    private static final String SERVER_URL = "https://api.netease.im/sms/sendcode.action";//请求的URL
    private static final String APP_KEY = "50b7f5d970d820bc631ad430f461f334";//网易云分配的账号
    private static final String APP_SECRET = "377c69c2c0d9";//密码
    private static final String MOULD_ID = "9574450";//模板ID
    private static final String NONCE = "123456";//随机数
    private static final String CODELEN = "6";//验证码长度，范围4～10，默认为4


    public static String sendMsg(String phone)
    {
        URL url = null;
        HttpURLConnection conn = null;
        StringBuffer stringBuffer = null;

        try
        {
            url = new URL(SERVER_URL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("AppKey", APP_KEY);
            String curTime = String.valueOf((new Date().getTime() / 1000L));
            String checkSum = CheckSumBuilder.getCheckSum(APP_SECRET, NONCE, curTime);
            conn.setRequestProperty("CheckSum", checkSum);
            conn.setRequestProperty("CurTime", curTime);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
            conn.setRequestProperty("Nonce", NONCE);
            conn.setConnectTimeout(5000);//time out
            conn.setDoInput(true);//can read
            conn.setDoOutput(true);//can write
            conn.setRequestMethod("POST");
            conn.connect();


            String encStr1 = URLEncoder.encode("Tom", "utf-8");
            String encStr2 = URLEncoder.encode("name", "utf-8");
            String params = "templateid=" + MOULD_ID + "&mobile=" + phone + "&codeLen=" + CODELEN + "&params=" + "[\"" + encStr1 + "\",\"" + encStr2 + "\"]";

            OutputStream outputStream = conn.getOutputStream();
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);


            bufferedWriter.write(params);
            bufferedWriter.flush();


            bufferedWriter.close();
            outputStreamWriter.close();
            outputStream.close();


            InputStream inputStream = conn.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);


            stringBuffer = new StringBuffer();
            String temp = null;
            while ((temp = bufferedReader.readLine()) != null) {
                stringBuffer.append(temp);
            }


            bufferedReader.close();
            inputStreamReader.close();
            inputStream.close();
        }
        catch (MalformedURLException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            conn.disconnect();
        }

        return stringBuffer.toString();
    }
}