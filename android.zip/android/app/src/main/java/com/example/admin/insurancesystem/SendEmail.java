package com.example.admin.insurancesystem;

public class SendEmail
{

}
