package com.example.admin.insurancesystem;

import java.util.Date;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import static java.lang.String.valueOf;

public class SendEmail
{
    public static String sendEmail(String toAddress)
    {
        Email email = new Email();
        email.setMailServerHost("smtp.163.com");
        email.setMailServerPort("25");
        email.setValidate(true);
        email.setUserName("wzh434986859@163.com");
        email.setPassword("b840323");
        email.setFromAddress("wzh434986859@163.com");
        email.setToAddress(toAddress);
        email.setSubject("This is just a test email.");
        String code = valueOf((int)(Math.random() * 1000000));
        email.setContent("Our verify code is: " + code + ".");

        //check if authenticator
        MyAuthenticator authenticator = null;
        Properties pro = email.getProperties();

        if(email.isValidate())
        {
            //if needed, create authenticator
            authenticator = new MyAuthenticator(email.getUserName(),email.getPassword());
        }
        //create session
        Session sendMailSession = Session.getDefaultInstance(pro,authenticator);

        try
        {
            Message mailMassage = new MimeMessage(sendMailSession);
            //set from address
            Address from = new InternetAddress(email.getFromAddress());
            mailMassage.setFrom(from);
            //set to address
            Address to = new InternetAddress(email.getToAddress());
            mailMassage.setRecipient(Message.RecipientType.TO,to);
            //set subject
            mailMassage.setSubject(email.getSubject());
            //set date
            mailMassage.setSentDate(new Date());
            //set content
            String mailContent = email.getContent();
            mailMassage.setText(mailContent);

            System.out.println("=====================");
            try
            {
                Transport.send(mailMassage);
            }
            catch (Exception e)
            {
                System.out.println(e.fillInStackTrace());
            }
            System.out.println(code);
            System.out.println("----------------------");
        }
        catch (MessagingException e)
        {
            e.printStackTrace();
        }

        return code;
    }
}
