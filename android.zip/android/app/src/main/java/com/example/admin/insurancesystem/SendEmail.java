package com.example.admin.insurancesystem;

import java.util.Date;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendEmail
{
    public static boolean sendEmail(Email email)
    {
        //判断是否需要身份验证
        MyAuthenticator authenticator = null;
        Properties pro = email.getProperties();

        if(email.isValidate())
        {
            //如果需要身份验证，则创建密码验证器
            authenticator = new MyAuthenticator(email.getUserName(),email.getPassword());
        }
        //根据会话属性和密码验证器构造一个发送邮件的session
        Session sendMailSession = Session.getDefaultInstance(pro,authenticator);

        try
        {
            //根据session创建一个邮件消息
            Message mailMassage = new MimeMessage(sendMailSession);
            //创建邮件的发送者地址
            Address from = new InternetAddress(email.getFromAddress());
            //设置邮件消息的发送者
            mailMassage.setFrom(from);
            //创建邮件的接收地址，并设置到邮件消息中
            Address to = new InternetAddress(email.getToAddress());
            mailMassage.setRecipient(Message.RecipientType.TO,to);
            //设置邮件的主题
            mailMassage.setSubject(email.getSubject());
            //设置邮件的发送时间
            mailMassage.setSentDate(new Date());

            //设置邮件的主要内容
            String mailContent = email.getContent();
            mailMassage.setText(mailContent);

            System.out.println("=====================");
            try
            {
                Transport.send(mailMassage);
            }
            catch (Exception e)
            {
                System.out.println(e.fillInStackTrace());
            }
            //发送邮件

            System.out.println(mailMassage);
            System.out.println("----------------------");
            return true;
        }
        catch (MessagingException e)
        {
            e.printStackTrace();
            return false;
        }
    }
}
