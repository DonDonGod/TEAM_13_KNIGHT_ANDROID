package com.example.admin.insurancesystem;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class SignUpActivity extends AppCompatActivity
{
    private EditText editPhone;
    private EditText editCode;
    private EditText editPassword;
    private EditText editRepassword;
    private Button btnVerify;
    private Button btnSignup;
    private ImageView btnBack;
    private TextView textSignin;

    private String state;
    private String SMSCode = "1314520";
    private SMSTimer timer = null;
    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 1)
            {
                if(state.substring(0,1).equals("S"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Succeed!",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SignUpActivity.this, SignActivity.class);
                    startActivity(intent);
                }
                else if(state.equals("Wrong: the user already exists"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Phone number has already existed. Please sign in or change another one.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(!state.substring(0,1).equals("S"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        editPhone = (EditText) this.findViewById(R.id.et_username);
        editCode = (EditText) this.findViewById(R.id.et_email);
        editPassword = (EditText) this.findViewById(R.id.et_password);
        editRepassword = (EditText) this.findViewById(R.id.Re_password);
        btnVerify = (Button) this.findViewById(R.id.button1);
        btnSignup = (Button) this.findViewById(R.id.btn_sign_up);
        btnBack = (ImageView) this.findViewById(R.id.iv_back);
        textSignin = (TextView) this.findViewById(R.id.tv_sign_in);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        if(timer != null)
        {
            timer.cancel();
            timer = null;
        }
    }

    public void verify(View v)
    {
        if(editPhone.getText().toString().equals(""))
        {
            Toast.makeText(getApplicationContext(),"Phone number can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else
        {
            System.out.println("Send code!!!!");
            Thread tread = new Thread(new Runnable()
            {
                @Override
                public void run()
                {
                    try
                    {
                        String getMsg = SendCode.sendMsg(editPhone.getText().toString());
                        System.out.println(getMsg);
                        JSONObject jsonObject = new JSONObject(getMsg);
                        SMSCode = jsonObject.getString("obj");
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
            });
            tread.start();

            btnVerify.setClickable(false);
            timer = new SMSTimer(btnVerify);
            timer.start();
        }
    }

    public void Sign_up(View v)
    {
        String phone = editPhone.getText().toString();
        String password = editPassword.getText().toString();
        String repassword = editRepassword.getText().toString();
        String code = editCode.getText().toString();

        if(phone.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Phone number can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if(code.equals(""))
        {
            Toast.makeText(getApplicationContext(),"SMS code can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if(password.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Password can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if(repassword.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Please retype your password.",Toast.LENGTH_SHORT).show();
        }
        else if(!repassword.equals(password))
        {
            Toast.makeText(getApplicationContext(),"Your two passwords are not the same. Please check again.",Toast.LENGTH_SHORT).show();
        }
        else if(!code.equals(SMSCode))
        {
            Toast.makeText(getApplicationContext(),"SMS code is wrong. Please check again.",Toast.LENGTH_SHORT).show();
        }
        else
        {
            final JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("phone", phone);
                jsonObject.put("password", password);
                System.out.println(jsonObject.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Thread tread = new Thread(new Runnable() {
                @Override
                public void run() {
                    String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/user/register");
                    System.out.println("The string get from server is: " + str);
                    state = str;
                    Message msg = new Message();
                    msg.what = 1;
                    handler.sendMessage(msg);
                }
            });
            tread.start();

            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Please want......");
            progressDialog.setMessage("Signing up......");
            progressDialog.setIndeterminate(true);
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            Thread thread = new Thread()
            {
                public void run()
                {
                    try
                    {
                        sleep(10*1000);
                    }
                    catch(InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                    progressDialog.cancel();
                    Message msg = new Message();
                    msg.what = 101;
                    handler.sendMessage(msg);
                }
            };
            thread.start();
        }
    }

    public void Sign_in(View v)
    {
        Intent intent = new Intent(SignUpActivity.this, SignActivity.class);
        startActivity(intent);
    }

    public void Back(View v)
    {
        finish();
    }
}
