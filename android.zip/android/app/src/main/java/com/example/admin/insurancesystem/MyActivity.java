package com.example.admin.insurancesystem;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class MyActivity extends AppCompatActivity
{
    ImageView btnback;
    ImageView imgPhoto;
    TextView textPhoto;
    TextView textId;
    TextView textName;
    TextView textEmail;
    TextView textPassword;
    ImageButton btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_me);

        btnback = (ImageView) this.findViewById(R.id.btn_back);
        imgPhoto = (ImageView) this.findViewById(R.id.ImageView01);
        textPhoto = (TextView) this.findViewById(R.id.textView1);
        textId = (TextView) this.findViewById(R.id.textView3);
        textName = (TextView) this.findViewById(R.id.textView4);
        textEmail = (TextView) this.findViewById(R.id.textView5);
        textPassword = (TextView) this.findViewById(R.id.textView6);
        btnLogout = (ImageButton) this.findViewById(R.id.imageButton1);
    }

    public void Open_photo(View v)
    {

    }

    public void Change_photo(View v)
    {

    }

    public void Set_id(View v)
    {

    }

    public void Set_name(View v)
    {

    }

    public void Change_email(View v)
    {
        final Email email = new Email();
        email.setMailServerHost(host);
        email.setMailServerPort(post);
        email.setValidate(true);
        email.setUserName(fromAdd);//邮箱地址
        email.setPassword(fromPsw);//邮箱密码
        email.setFromAddress(fromAdd);//发送的邮箱
        email.setToAddress(toAdd);//发到哪个邮箱
        email.setSubject("哈哈");//发送标题
        email.setContent("某某平台验证码："+code);//发送文本
        final Email sms = new Email();
        new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                System.out.println("多线程部分");
                sms.sendTextMail(email);
            }
        }).start();
    }

    public void Change_password(View v)
    {

    }

    public void Logout(View v)
    {

    }

    public void Back(View v)
    {

    }
}
