package com.example.admin.insurancesystem;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;

import static java.lang.String.valueOf;

public class MyActivity extends AppCompatActivity
{
    private ImageView btnback;
    private TextView textPhone;
    private TextView textId;
    private TextView textName;
    private TextView textEmail;
    private TextView textPassword;
    private ImageButton btnLogout;

    private String state;
    private String personId;
    private String fullName;
    private String emailAddress;
    private String emailCode = "1314520";
    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 6)
            {
                if(state.equals("100"))
                {
                    progressDialog.cancel();
                    textPhone.setText(SignActivity.PHONE);
                    textId.setText(personId);
                    textName.setText(fullName);
                    textEmail.setText(emailAddress);
                }
                else
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"This user does not exist.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(!state.equals("100"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_me);

        btnback = (ImageView) this.findViewById(R.id.btn_back);
        textPhone = (TextView) this.findViewById(R.id.textView1);
        textId = (TextView) this.findViewById(R.id.textView3);
        textName = (TextView) this.findViewById(R.id.textView4);
        textEmail = (TextView) this.findViewById(R.id.textView5);
        textPassword = (TextView) this.findViewById(R.id.textView6);
        btnLogout = (ImageButton) this.findViewById(R.id.imageButton1);

        Thread tread = new Thread(new Runnable() {
            @Override
            public void run()
            {
                String str = SendServer.sendServer(SignActivity.PHONE, "http://101.132.96.76:8080/user/personal_information/pi");
                System.out.println("The string get from server is: " + str);
                try
                {
                    JSONObject getJsonObject = new JSONObject(str);
                    state = getJsonObject.getString("Checkcode");
                    personId = getJsonObject.getString("id_number");
                    fullName = getJsonObject.getString("Fullname");
                    emailAddress = getJsonObject.getString("email");

                    Message msg = new Message();
                    msg.what = 6;
                    handler.sendMessage(msg);
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
            }
        });
        tread.start();

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please want......");
        progressDialog.setMessage("Loading......");
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        Thread thread = new Thread()
        {
            public void run()
            {
                try
                {
                    sleep(10*1000);
                }
                catch(InterruptedException e)
                {
                    e.printStackTrace();
                }
                progressDialog.cancel();
                Message msg = new Message();
                msg.what = 101;
                handler.sendMessage(msg);
            }
        };
        thread.start();
    }

    public void Change_photo(View v)
    {

    }

    public void Change_email(View v)
    {
        final String toAddress = "wzh434986859@163.com";

        new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                emailCode = SendEmail.sendEmail(toAddress);
            }
        }).start();
    }

    public void Change_password(View v)
    {

    }

    public void Logout(View v)
    {

    }

    public void Back(View v)
    {

    }
}
