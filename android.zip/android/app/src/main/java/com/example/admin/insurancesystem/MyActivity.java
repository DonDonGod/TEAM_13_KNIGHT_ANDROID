package com.example.admin.insurancesystem;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class MyActivity extends AppCompatActivity
{
    private ImageView btnback;
    private TextView textPhone;
    private TextView textId;
    private TextView textName;
    private TextView textEmail;
    private TextView textPassword;
    private Button btnLogout;

    private String state = "";
    private String message = "";
    private String personId;
    private String fullName;
    private String emailAddress;
    //private String emailCode = "1314520";
    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 6)
            {
                if(state.equals("100"))
                {
                    progressDialog.cancel();
                    textPhone.setText(SignActivity.PHONE);
                    textId.setText(personId);
                    textName.setText(fullName);
                    textEmail.setText(emailAddress);
                }
                else if(state.equals("200"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"This user does not exist.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(!state.equals("100"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_me);

        btnback = (ImageView) this.findViewById(R.id.me_back);
        textPhone = (TextView) this.findViewById(R.id.me_PhoneNumber);
        textId = (TextView) this.findViewById(R.id.me_ID);
        textName = (TextView) this.findViewById(R.id.me_Name);
        textEmail = (TextView) this.findViewById(R.id.me_email);
        textPassword = (TextView) this.findViewById(R.id.me_password);
        btnLogout = (Button) this.findViewById(R.id.me_log_out);


        final JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("phone_number", SignActivity.PHONE);
            System.out.println(jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Thread tread = new Thread(new Runnable() {
            @Override
            public void run()
            {
                String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/user/personal_information/pi");
                System.out.println("The string get from server is: " + str);
                try
                {
                    JSONObject getMsg = new JSONObject(str);
                    state = getMsg.getString("Checkcode");
                    message = getMsg.getString("Message");

                    try
                    {
                        JSONObject getJsonObject = new JSONObject(message);
                        personId = getJsonObject.getString("id_number");
                        fullName = getJsonObject.getString("fullname");
                        emailAddress = getJsonObject.getString("email");
                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
                Message msg = new Message();
                msg.what = 6;
                handler.sendMessage(msg);
            }
        });
        tread.start();

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please wait......");
        progressDialog.setMessage("Loading......");
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        Thread thread = new Thread()
        {
            public void run()
            {
                try
                {
                    sleep(10*1000);
                }
                catch(InterruptedException e)
                {
                    e.printStackTrace();
                }
                progressDialog.cancel();
                Message msg = new Message();
                msg.what = 101;
                handler.sendMessage(msg);
            }
        };
        thread.start();
    }

    public void Change_email(View v)
    {
        Intent intent = new Intent(MyActivity.this, ChangeEmailActivity.class);
        startActivity(intent);
    }

    public void Change_password(View v)
    {
        Intent intent = new Intent(MyActivity.this, ChangePasswordActivity.class);
        startActivity(intent);
    }

    public void Logout(View v)
    {
        Intent intent = new Intent(MyActivity.this, MainActivity.class);
        startActivity(intent);
    }

    public void Back(View v)
    {
        finish();
    }
}
