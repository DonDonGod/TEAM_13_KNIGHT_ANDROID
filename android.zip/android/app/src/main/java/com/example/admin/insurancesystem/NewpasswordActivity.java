package com.example.admin.insurancesystem;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class NewpasswordActivity extends AppCompatActivity
{
    private EditText editPassword;
    private EditText editRepassword;
    private Button btnReset;

    private String state;
    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 1)
            {
                if(state.equals("Success"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Succeed!",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(NewpasswordActivity.this, SignActivity.class);
                    startActivity(intent);
                }
                else if(state.equals("Failed"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Something wrong with the server. Please try it later.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(!state.equals("Success"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.);

        editPassword = (EditText) this.findViewById(R.id.);
        editRepassword = (EditText) this.findViewById(R.id.);
        btnReset = (Button) this.findViewById(R.id.);
    }

    public void Reset(View v)
    {
        String phone = editPhone.getText().toString();
        String code = editCode.getText().toString();

        if(phone.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Phone number can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if(code.equals(""))
        {
            Toast.makeText(getApplicationContext(),"SMS code can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if(!phone.equals(SMSPhone) || !code.equals(SMSCode))
        {
            Toast.makeText(getApplicationContext(),"SMS code is wrong. Please check again.",Toast.LENGTH_SHORT).show();
        }
        else
        {
            final JSONObject jsonObject = new JSONObject();
            try
            {
                jsonObject.put("phone", phone);
                System.out.println(jsonObject.toString());
            }
            catch (JSONException e)
            {
                e.printStackTrace();
            }
            Thread tread = new Thread(new Runnable()
            {
                @Override
                public void run()
                {
                    String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/user/register");
                    System.out.println("The string get from server is: " + str);
                    state = str;
                    Message msg = new Message();
                    msg.what = 1;
                    handler.sendMessage(msg);
                }
            });
            tread.start();

            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Please want......");
            progressDialog.setMessage("Checking phone number......");
            progressDialog.setIndeterminate(true);
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            Thread thread = new Thread()
            {
                public void run()
                {
                    try
                    {
                        sleep(10*1000);
                    }
                    catch(InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                    progressDialog.cancel();
                    Message msg = new Message();
                    msg.what = 101;
                    handler.sendMessage(msg);
                }
            };
            thread.start();
        }
    }
}
