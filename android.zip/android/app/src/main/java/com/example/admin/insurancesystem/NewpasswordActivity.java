package com.example.admin.insurancesystem;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class NewpasswordActivity extends AppCompatActivity
{
    private EditText editPassword;
    private EditText editRepassword;
    private Button btnReset;
    private ImageView btnBack;
    private ImageView imgPasswordStrength;

    private int passwordStrength = 0;
    private String state = "";
    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 1)
            {
                if(state.equals("100"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Succeed!",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(NewpasswordActivity.this, SignActivity.class);
                    startActivity(intent);
                }
                else if(state.equals("200"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Something wrong with the server. Please try it later.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(!state.equals("100"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password_step2);

        editRepassword = (EditText) this.findViewById(R.id.forget2_re_password);
        btnReset = (Button) this.findViewById(R.id.forget2_nmsl);
        btnBack = (ImageView) this.findViewById(R.id.forget2_iv_back);
        imgPasswordStrength = (ImageView) this.findViewById(R.id.img_forgetPassword);
        editPassword = (EditText) this.findViewById(R.id.forget2_new_password);
        editPassword.addTextChangedListener(new TextWatcher()
        {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {
                if(passwordStrength < 40)
                {
                    imgPasswordStrength.setImageResource(R.drawable.password_strength_weak_2);
                }
                else if(passwordStrength >= 40 && passwordStrength < 80)
                {
                    imgPasswordStrength.setImageResource(R.drawable.password_strength_medium_2);
                }
                else if(passwordStrength >= 80)
                {
                    imgPasswordStrength.setImageResource(R.drawable.password_strength_high_2);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {
                passwordStrength =  CheckPassword.checkPasswordStrength(editPassword.getText().toString());
            }

            @Override
            public void afterTextChanged(Editable s)
            {
                if(passwordStrength < 30)
                {
                    imgPasswordStrength.setImageResource(R.drawable.password_strength_weak_2);
                }
                else if(passwordStrength >= 30 && passwordStrength < 75)
                {
                    imgPasswordStrength.setImageResource(R.drawable.password_strength_medium_2);
                }
                else if(passwordStrength >= 75)
                {
                    imgPasswordStrength.setImageResource(R.drawable.password_strength_high_2);
                }
            }
        });
    }

    public void Reset(View v)
    {
        String password = editPassword.getText().toString();
        String rePassword = editRepassword.getText().toString();

        if(password.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Password can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if(rePassword.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Please double check your new password.",Toast.LENGTH_SHORT).show();
        }
        else if(!password.equals(rePassword))
        {
            Toast.makeText(getApplicationContext(),"Two passwords are not the same. Please check again.",Toast.LENGTH_SHORT).show();
        }
        else
        {
            final JSONObject jsonObject = new JSONObject();
            try
            {
                jsonObject.put("phone_number", ForgetActivity.SMSPhone);
                jsonObject.put("password", password);
                System.out.println(jsonObject.toString());
            }
            catch (JSONException e)
            {
                e.printStackTrace();
            }
            Thread tread = new Thread(new Runnable()
            {
                @Override
                public void run()
                {
                    String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/user/personal_information/change_password");
                    System.out.println("The string get from server is: " + str);
                    try
                    {
                        JSONObject getJsonObject = new JSONObject(str);
                        state = getJsonObject.getString("Checkcode");
                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                    Message msg = new Message();
                    msg.what = 1;
                    handler.sendMessage(msg);
                }
            });
            tread.start();

            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Please want......");
            progressDialog.setMessage("Changing new password......");
            progressDialog.setIndeterminate(true);
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            Thread thread = new Thread()
            {
                public void run()
                {
                    try
                    {
                        sleep(10*1000);
                    }
                    catch(InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                    progressDialog.cancel();
                    Message msg = new Message();
                    msg.what = 101;
                    handler.sendMessage(msg);
                }
            };
            thread.start();
        }
    }

    public void Back(View v)
    {
        finish();
    }
}
