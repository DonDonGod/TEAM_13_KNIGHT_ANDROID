package com.example.admin.insurancesystem;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;


public class ClaimActivity extends AppCompatActivity
{
    private EditText editPolicyId;
    private EditText editName;
    private EditText editId;
    private EditText editPhone;
    private EditText editEmail;
    private EditText editAddressCode;
    private RadioGroup rgType;
    private EditText editPlace;
    private DatePicker dateTime;
    private EditText editDetail;
    private EditText editRemark;
    private EditText editValue;

    private String state;
    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 5)
            {
                if(state.equals("Saved"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Your claim has been upload successfully. It will take 2~3 days. Please wait for the result.",Toast.LENGTH_SHORT).show();
                    finish();
                }
                else if(state.equals("it aleady exists"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"This form has already existed.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(!state.equals("Saved"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.excel);

        editPolicyId = (EditText) this.findViewById(R.id.PolicyNumber);
        editName = (EditText) this.findViewById(R.id.FullName);
        editId = (EditText) this.findViewById(R.id.ID);
        editPhone = (EditText) this.findViewById(R.id.PhoneNumber);
        editEmail = (EditText) this.findViewById(R.id.EmailAddress);
        editAddressCode = (EditText) this.findViewById(R.id.PostalCode);
        rgType = (RadioGroup) this.findViewById(R.id.ThingsLost);
        editPlace = (EditText) this.findViewById(R.id.place);
        dateTime = (DatePicker) this.findViewById(R.id.datePicker1);
        editDetail = (EditText) this.findViewById(R.id.details);
        editRemark = (EditText) this.findViewById(R.id.remark);
        editValue = (EditText) this.findViewById(R.id.pricy);
    }

    public void Upload_claim(View v) {
        String claimPolicyId = editPolicyId.getText().toString();
        String claimTime = Calendar.getInstance().get(Calendar.HOUR_OF_DAY) + ":" + Calendar.getInstance().get(Calendar.MINUTE);
        String claimDate = dateTime.getDayOfMonth() + "/" + dateTime.getDayOfMonth() + "/" + dateTime.getDayOfMonth();
        String claimDescription = editDetail.getText().toString();
        String claimRemark = editRemark.getText().toString();
        String claimValue = editValue.getText().toString();

        if (claimPolicyId.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Policy ID can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if (claimDate.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Losing date can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if (claimDescription.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Description can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if (claimRemark.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Remark can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if (claimValue.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Value can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else
       {
            final JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("police_number", claimPolicyId);
                jsonObject.put("time", claimTime);
                jsonObject.put("date", claimDate);
                jsonObject.put("reason", claimDescription);
                jsonObject.put("remark", claimRemark);
                jsonObject.put("price", claimValue);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Thread tread = new Thread(new Runnable() {
                @Override
                public void run() {
                    String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/user/lost_luggage");
                    System.out.println("The string get from server is: " + str);
                    state = str;
                    Message msg = new Message();
                    msg.what = 5;
                    handler.sendMessage(msg);
                }
            });
            tread.start();

            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Please want......");
            progressDialog.setMessage("Uploading......");
            progressDialog.setIndeterminate(true);
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            Thread thread = new Thread() {
                public void run() {
                    try {
                        sleep(10 * 1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    progressDialog.cancel();
                    Message msg = new Message();
                    msg.what = 101;
                    handler.sendMessage(msg);
                }
            };
            thread.start();
        }
    }
}
