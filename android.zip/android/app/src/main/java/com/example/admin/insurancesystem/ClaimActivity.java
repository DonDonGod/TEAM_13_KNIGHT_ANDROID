package com.example.admin.insurancesystem;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;


public class ClaimActivity extends AppCompatActivity
{
    private EditText editPolicyId;
    private EditText editPolicyName;
    private EditText editPhone;
    private EditText editPlace;
    private EditText editDetail;
    private RadioGroup rgValue;
    private RadioButton rgValue1;
    private RadioButton rgValue2;
    private RadioButton rgValue3;
    private RadioButton rgValue4;
    ////////////////private ImageView imgPhoto;

    private boolean isEdit = false;
    private String state = "";
    ///////////private static final int IMAGE = 1;
    private ProgressDialog progressDialog = null;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            if(msg.what == 5)
            {
                if(state.equals("100"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"Your claim has been upload successfully. It will take 2~3 days. Please wait for the result.",Toast.LENGTH_SHORT).show();
                    finish();
                }
                else if(state.equals("202"))
                {
                    progressDialog.cancel();
                    Toast.makeText(getApplicationContext(),"This form has already existed.",Toast.LENGTH_SHORT).show();
                }
            }
            else if(msg.what == 101)
            {
                if(!state.equals("100"))
                {
                    Toast.makeText(getApplicationContext(), "Something wrong with network. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_excel);

        editPolicyId = (EditText) this.findViewById(R.id.policyNumber_input);
        editPolicyName = (EditText) this.findViewById(R.id.policyName_Input);
        editPhone = (EditText) this.findViewById(R.id.policyPhone_Input);
        editPlace = (EditText) this.findViewById(R.id.policyLocation_Input);
        editDetail = (EditText) this.findViewById(R.id.policyReason_Input);
        rgValue = (RadioGroup) this.findViewById(R.id.price_group);
        rgValue1 = (RadioButton) this.findViewById(R.id.price_0_100);
        rgValue2 = (RadioButton) this.findViewById(R.id.price_100_1000);
        rgValue3 = (RadioButton) this.findViewById(R.id.price_1000_10000);
        rgValue4 = (RadioButton) this.findViewById(R.id.price_10000);
       /////////////////////// imgPhoto = (ImageView) this.findViewById(R.id.);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        isEdit = bundle.getBoolean("isEdit");

        if (isEdit)
        {
            editPolicyId.setText(bundle.getString("edit_policyID"));
            editPolicyName.setText(bundle.getString("edit_policyName"));
            editPhone.setText(bundle.getString("edit_phone"));
            editPlace.setText(bundle.getString("edit_place"));
            editDetail.setText(bundle.getString("edit_description"));
            String edit_value = bundle.getString("edit_value");
            if(edit_value.equals("101"))
            {
                rgValue1.setChecked(true);
            }
            else if(edit_value.equals("102"))
            {
                rgValue2.setChecked(true);
            }
            else if(edit_value.equals("103"))
            {
                rgValue3.setChecked(true);
            }
            else if(edit_value.equals("104"))
            {
                rgValue4.setChecked(true);
            }
        }
    }


    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        //获取图片路径
        if (requestCode == IMAGE && resultCode == Activity.RESULT_OK && data != null) {
            Uri selectedImage = data.getData();
            String[] filePathColumns = {MediaStore.Images.Media.DATA};
            Cursor c = getContentResolver().query(selectedImage, filePathColumns, null, null, null);
            c.moveToFirst();
            int columnIndex = c.getColumnIndex(filePathColumns[0]);
            String imagePath = c.getString(columnIndex);
            Bitmap bm = BitmapFactory.decodeFile(imagePath);
            imgPhoto.setImageBitmap(bm);
            c.close();
        }
    }*/


    public void Upload_claim(View v)
    {
        String claimPolicyId = editPolicyId.getText().toString();
        String claimPolicyName = editPolicyName.getText().toString();
        String claimPhone = editPhone.getText().toString();
        String claimTime = Calendar.getInstance().get(Calendar.YEAR) + "/" + Calendar.getInstance().get(Calendar.MONTH) + "/" + Calendar.getInstance().get(Calendar.DAY_OF_MONTH) + "/" + Calendar.getInstance().get(Calendar.HOUR_OF_DAY) + "/" + Calendar.getInstance().get(Calendar.MINUTE);
        String claimPlace = editPlace.getText().toString();
        String claimDescription = editDetail.getText().toString();
        String claimValue = "";
        if(rgValue1.isChecked())
        {
            claimValue = "101";
        }
        else if(rgValue2.isChecked())
        {
            claimValue = "102";
        }
        else if(rgValue3.isChecked())
        {
            claimValue = "103";
        }
        else if(rgValue4.isChecked())
        {
            claimValue = "104";
        }
        /////////////String claimPhoto = imgPhoto.getDrawable().toString();

        if (claimPolicyId.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Policy ID can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if (claimPhone.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Phone can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if (claimPlace.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Place can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if (claimDescription.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Description can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else if (claimValue.equals(""))
        {
            Toast.makeText(getApplicationContext(),"Value can not be empty.",Toast.LENGTH_SHORT).show();
        }
        else
       {
            final JSONObject jsonObject = new JSONObject();
            try
            {
                jsonObject.put("policy_number", claimPolicyId);
                jsonObject.put("policy_name", claimPolicyName);
                jsonObject.put("phone_number", claimPhone);
                jsonObject.put("time", claimTime);
                jsonObject.put("place", claimPlace);
                jsonObject.put("reason", claimDescription);
                jsonObject.put("price", claimValue);
                jsonObject.put("picture", "this_is_a_photo");
                jsonObject.put("states", "1@@0@@0");
                /*jsonObject.put("police_number", "10001");
                jsonObject.put("phone_number", "123");
                jsonObject.put("time", claimTime);
                jsonObject.put("place", "Beijing");
                jsonObject.put("reason", "asdqwezxc123456789");
                jsonObject.put("price", "101");
                jsonObject.put("picture", "");*/
            }
            catch (JSONException e)
            {
                e.printStackTrace();
            }
            Thread tread = new Thread(new Runnable() {
                @Override
                public void run() {
                    String str = SendServer.sendServer(jsonObject.toString(), "http://101.132.96.76:8080/user/lost_luggage/submit_OR_update");
                    System.out.println("The string get from server is: " + str);
                    try
                    {
                        JSONObject getJsonObject = new JSONObject(str);
                        state = getJsonObject.getString("Checkcode");
                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                    Message msg = new Message();
                    msg.what = 5;
                    handler.sendMessage(msg);
                }
            });
            tread.start();

            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Please want......");
            progressDialog.setMessage("Uploading......");
            progressDialog.setIndeterminate(true);
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            Thread thread = new Thread() {
                public void run() {
                    try {
                        sleep(10 * 1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    progressDialog.cancel();
                    Message msg = new Message();
                    msg.what = 101;
                    handler.sendMessage(msg);
                }
            };
            thread.start();
        }
    }

    /*public void AddPhoto(View v)
    {
        Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, IMAGE);
    }*/

    public void Back(View v)
    {
        finish();
    }
}
