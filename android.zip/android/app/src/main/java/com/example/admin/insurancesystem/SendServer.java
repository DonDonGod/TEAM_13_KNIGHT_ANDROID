package com.example.admin.insurancesystem;

import android.graphics.drawable.Drawable;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.UUID;

import static android.provider.ContactsContract.CommonDataKinds.StructuredName.PREFIX;

public class SendServer
{
    //private static final String URL_STR = "http://111.111.1.1:8080/testweb/Server";//http://101.132.96.76:8080/person/save?name=Don
    //http://101.132.96.76:8080/

    public static String sendServer(String msg, String urlString)
    {
        URL url = null;
        HttpURLConnection conn = null;
        StringBuffer stringBuffer = new StringBuffer();

        try
        {
            url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(1000);//time out
            conn.setDoInput(true);//can read
            conn.setDoOutput(true);//can write
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.connect();


            OutputStream outputStream = conn.getOutputStream();
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);


            bufferedWriter.write(msg);
            bufferedWriter.flush();


            bufferedWriter.close();
            outputStreamWriter.close();
            outputStream.close();


            InputStream inputStream = conn.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);


            String temp = null;
            while((temp = bufferedReader.readLine()) != null)
            {
                stringBuffer.append(temp);
            }


            bufferedReader.close();
            inputStreamReader.close();
            inputStream.close();
        }
        catch(MalformedURLException e)
        {
            e.printStackTrace();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            conn.disconnect();
        }

        return stringBuffer.toString();
    }

    /*public static String sendPhoto(Drawable photo, String urlString)
    {
        URL url = null;
        HttpURLConnection conn = null;
        String BOUNDARY = UUID.randomUUID().toString();
        StringBuffer stringBuffer = new StringBuffer();

        try
        {
            url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(1000);//time out
            conn.setDoInput(true);//can read
            conn.setDoOutput(true);//can write
            conn.setRequestMethod("POST");*/
           ////////////////////////////// conn.setRequestProperty("Accept","*/*");
            /*conn.setRequestProperty("Connection", "keep-alive");
            conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + BOUNDARY);
            conn.connect();

            if (photo != null) {
                DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
                StringBuffer sb = new StringBuffer();

                String params = "";
                if (param != null && param.size() > 0) {
                    Iterator<String> it = param.keySet().iterator();
                    while (it.hasNext()) {
                        sb = null;
                        sb = new StringBuffer();
                        String key = it.next();
                        String value = param.get(key);
                        sb.append(PREFIX).append(BOUNDARY).append(LINE_END);
                        sb.append("Content-Disposition: form-data; name=\"")
                                .append(key)
                                .append("\"")
                                .append(LINE_END)
                                .append(LINE_END);
                        sb.append(value).append(LINE_END);
                        params = sb.toString();
                        dos.write(params.getBytes());
                    }
                }
                sb = new StringBuffer();
                sb.append(PREFIX);
                sb.append(BOUNDARY);
                sb.append(LINE_END);
                sb.append("Content-Disposition: form-data; name=\"")
                        .append("avatar")
                        .append("\"")
                        .append(";filename=\"")
                        .append(imageName)
                        .append("\"\n");
                sb.append("Content-Type: image/png");
                sb.append(LINE_END).append(LINE_END);
                dos.write(sb.toString().getBytes());
                InputStream is = Drawable2InputStream(file);
                byte[] bytes = new byte[1024];
                int len = 0;
                while ((len = is.read(bytes)) != -1) {
                    dos.write(bytes, 0, len);
                }
                is.close();
                dos.write(LINE_END.getBytes());
                byte[] end_data = (PREFIX + BOUNDARY + PREFIX + LINE_END).getBytes();
                dos.write(end_data);
                dos.flush();



                InputStream inputStream = conn.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);


                String temp = null;
                while ((temp = bufferedReader.readLine()) != null) {
                    stringBuffer.append(temp);
                }


                bufferedReader.close();
                inputStreamReader.close();
                inputStream.close();
            }
        }
        catch(MalformedURLException e)
        {
            e.printStackTrace();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        catch (MalformedURLException e) {
            e.printStackTrace();
        }
        finally
        {
            conn.disconnect();
        }

        return stringBuffer.toString();
    }*/
}
