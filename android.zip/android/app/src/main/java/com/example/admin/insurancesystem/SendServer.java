package com.example.admin.insurancesystem;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class SendServer
{
    //private static final String URL_STR = "http://111.111.1.1:8080/testweb/Server";//http://101.132.96.76:8080/person/save?name=Don
    //http://101.132.96.76:8080/

    public static String sendServer(String msg, String urlString)
    {
        URL url = null;
        HttpURLConnection conn = null;
        StringBuffer stringBuffer = new StringBuffer();

        try
        {
            url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(1000);//time out
            conn.setDoInput(true);//can read
            conn.setDoOutput(true);//can write
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.connect();


            OutputStream outputStream = conn.getOutputStream();
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);


            bufferedWriter.write(msg);
            bufferedWriter.flush();


            bufferedWriter.close();
            outputStreamWriter.close();
            outputStream.close();


            InputStream inputStream = conn.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);


            String temp = null;
            while((temp = bufferedReader.readLine()) != null)
            {
                stringBuffer.append(temp);
            }


            bufferedReader.close();
            inputStreamReader.close();
            inputStream.close();
        }
        catch(MalformedURLException e)
        {
            e.printStackTrace();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            conn.disconnect();
        }

        return stringBuffer.toString();
    }

    public static Bitmap receivePhoto(String msg, String urlString)
    {
        URL url = null;
        HttpURLConnection conn = null;
        Bitmap bm = null;

        try
        {
            url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(1000);//time out
            conn.setDoInput(true);//can read
            conn.setDoOutput(true);//can write
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.connect();


            OutputStream outputStream = conn.getOutputStream();
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
            BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);


            bufferedWriter.write(msg);
            bufferedWriter.flush();


            bufferedWriter.close();
            outputStreamWriter.close();
            outputStream.close();


            InputStream inputStream = conn.getInputStream();
            System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            System.out.println("The inputStream is: " + inputStream.toString());
            System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            bm = BitmapFactory.decodeStream(inputStream);
            inputStream.close();
        }
        catch(MalformedURLException e)
        {
            e.printStackTrace();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            conn.disconnect();
        }

        return bm;
    }
}
